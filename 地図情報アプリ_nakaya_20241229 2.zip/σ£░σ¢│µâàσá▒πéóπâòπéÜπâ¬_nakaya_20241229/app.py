
#pip install streamlit pandas chardet folium streamlit-folium


import streamlit as st
import pandas as pd
import chardet
import gzip
import io
import folium
from streamlit_folium import folium_static

# 📌 エンコーディングを自動検出
def detect_encoding(file):
    raw_data = file.read(10000)
    result = chardet.detect(raw_data)
    encoding = result['encoding']
    confidence = result['confidence']
    file.seek(0)  # ポインタをリセット
    return encoding, confidence

# 📌 圧縮ファイルの解凍
def decompress_file(file, compression_type):
    if compression_type == 'gzip':
        with gzip.GzipFile(fileobj=file) as gz:
            decompressed_data = gz.read()
        return io.BytesIO(decompressed_data)
    else:
        st.error(f"未対応の圧縮形式: {compression_type}")
        return None

# 📌 CSVデータの読み込み
def load_data(uploaded_file):
    filename = uploaded_file.name
    if filename.endswith('.gz'):
        decompressed_file = decompress_file(uploaded_file, 'gzip')
        if decompressed_file is None:
            return None
        file_to_read = decompressed_file
    else:
        file_to_read = uploaded_file

    encoding, confidence = detect_encoding(file_to_read)
    st.write(f"推定エンコーディング: {encoding} (信頼度: {confidence:.2f})")

    if encoding is None:
        st.error("エンコーディングを検出できませんでした。手動で指定してください。")
        return None

    try:
        df = pd.read_csv(file_to_read, encoding=encoding)
        # 緯度・経度を数値型に強制変換（エラー時はNaNにする）
        df['緯度'] = pd.to_numeric(df['緯度'], errors='coerce')
        df['経度'] = pd.to_numeric(df['経度'], errors='coerce')

        # 無効な緯度・経度データを除外
        df = df.dropna(subset=['緯度', '経度'])
        return df
    except UnicodeDecodeError as e:
        st.error(f"エンコーディングエラー: {e}")
    except pd.errors.EmptyDataError:
        st.error("ファイルにデータが含まれていません。")
    except pd.errors.ParserError as e:
        st.error(f"パーシングエラー: {e}")
    except Exception as e:
        st.error(f"予期せぬエラー: {e}")
    return None

# 📌 地図を表示する関数
def display_map(df, selected_industries):
    if '緯度' not in df.columns or '経度' not in df.columns:
        st.error("CSVファイルに '緯度' および '経度' カラムが含まれている必要があります。")
        return
    if '業種' not in df.columns:
        st.error("CSVファイルに '業種' カラムが含まれている必要があります。")
        return
    
    m = folium.Map(location=[df['緯度'].mean(), df['経度'].mean()], zoom_start=5)

    for _, row in df.iterrows():
        if pd.notnull(row['緯度']) and pd.notnull(row['経度']) and row['業種'] in selected_industries:
            folium.Marker(
                location=[row['緯度'], row['経度']],
                popup=row.get('name', 'No Name'),
                tooltip=row.get('name', 'No Name')
            ).add_to(m)
    
    folium_static(m)

# 📌 メイン関数
def main():
    st.title("🗺️ 地図情報アプリ（緯度・経度・業種対応）")
    st.write("""
    - CSVファイルをアップロードしてください。  
    - 必須カラム: **緯度**, **経度**, **業種**  
    - オプションカラム: **name**  
    """)

    uploaded_file = st.file_uploader("CSVファイルを選択してください", type=["csv", "gz"])

    if uploaded_file is not None:
        st.write(f"**ファイル名:** {uploaded_file.name}")
        st.write(f"**ファイルサイズ:** {uploaded_file.size} バイト")

        df = load_data(uploaded_file)

        if df is not None:
            st.success("ファイルの読み込みに成功しました！")
            st.write("📊 **データプレビュー:**")
            st.dataframe(df.head())

            if '業種' in df.columns:
                industries = df['業種'].unique()
                selected_industries = st.multiselect(
                    "表示する業種を選択してください:",
                    options=industries,
                    default=industries
                )
                st.write("🌍 **地図の表示:**")
                display_map(df, selected_industries)
            else:
                st.error("CSVに '業種' カラムが含まれていません。")
        else:
            st.error("ファイルの読み込みに失敗しました。")

if __name__ == "__main__":
    main()
