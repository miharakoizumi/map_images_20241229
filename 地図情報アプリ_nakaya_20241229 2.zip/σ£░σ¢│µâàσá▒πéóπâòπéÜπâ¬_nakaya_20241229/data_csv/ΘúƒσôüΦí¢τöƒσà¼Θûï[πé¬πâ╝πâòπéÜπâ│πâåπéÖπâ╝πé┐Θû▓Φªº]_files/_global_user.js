$(function() {
  $('.js-scroll').click(function() {
    var speed = 500;
    var e = $(this).attr("data-id");
    var t = $(e == "#" || e == "" ? 'html' : e);
    var i = t.offset().top;
    $('html, body').animate({scrollTop: i}, speed, 'swing');
    return false;
  });
});

$(function() {
  var topBtn = $('#topBtn');
  var speed = 500;
  topBtn.hide();
  $(window).scroll(function () {
      if ($(this).scrollTop() > 100) {
          topBtn.fadeIn();
      } else {
          topBtn.fadeOut();
      }
  });
  topBtn.click(function () {
    $('html, body').animate({scrollTop: 0}, speed, 'swing');
    return false;
  });
});

$(function(){
  $.fs_cookie = {
    version:1,
    create:function(e){
      e = $.extend({name:"fs_cookie", value:null, days:365}, e);
      var t = window.location.hostname + ":" + e.name,
          i = "";
      if(e.days){
        var a = new Date;
            a.setTime(a.getTime() + 24 * e.days * 60 * 60 * 1e3),
            i=";expires = " + a.toGMTString()
      }
      document.cookie = t + "=" + e.value + i + "; path=/"
    },
    read:function(e){
      e = e ? ":" + e: ":fs_cookie";
      for(var t = (e = window.location.hostname + e ) + "=", i = document.cookie.split(";"), a = 0; a < i.length; a++){
        for(var n = i[a]; " " == n.charAt(0);)
        n = n.substring(1, n.length);
        if(0 == n.indexOf(t))
        return n.substring(t.length, n.length)
      }
      return null
    },
    alertAll:function(){
      for(var e = document.cookie.split("; "), t = "", i = 0; i < e.length; i++)
        t += "["+i+"] " + e[i] + "\n";
        alert(t)
    }
  };
  var e = $('.js-fontAdjust'),
      t = $('html'),
      c = $('iframe').contents().find('html'),
      i = "is-current";
  e.on("click", function(){
    var e = $(this).attr("data-size"),
        c = $('iframe').contents().find('html'),
        i = $(this).attr("class"),
        n = "changeFontSize";
    if (c !== null)
        "is-current" !== i && ("m" == e ? (c.css("font-size", "100%").removeClass("is-fontSizeL is-fontSizeM"), $.fs_cookie.create({name:n, value:"100%"})):
                               "l" == e ? (c.css("font-size", "128.6%").removeClass("is-fontSizeL").addClass("is-fontSizeM"), $.fs_cookie.create({name:n, value:"128.6%"})):
                               "xl" == e && (c.css("font-size", "142.9%").removeClass("is-fontSizeM").addClass("is-fontSizeL"), $.fs_cookie.create({name:n, value:"142.9%"})));
    "is-current" !== i && ("m" == e ? (t.css("font-size", "100%").removeClass("is-fontSizeL is-fontSizeM"), $.fs_cookie.create({name:n, value:"100%"})):
                           "l" == e ? (t.css("font-size", "128.6%").removeClass("is-fontSizeL").addClass("is-fontSizeM"), $.fs_cookie.create({name:n, value:"128.6%"})):
                           "xl" == e && (t.css("font-size", "142.9%").removeClass("is-fontSizeM").addClass("is-fontSizeL"), $.fs_cookie.create({name:n, value:"142.9%"})));
    var a = $.fs_cookie.read("changeFontSize"),
        e = $('.js-fontAdjust'),
        i = "is-current";
    if(null === a) return!1;
    a.indexOf('100%') > -1 ? (e.removeClass(i), $('.js-fontAdjust[data-size="m"]').addClass(i)):
    a.indexOf('128.6%') > -1 ? (e.removeClass(i), $('.js-fontAdjust[data-size="l"]').addClass(i)):
    a.indexOf('142.9%') > -1 && (e.removeClass(i), $('.js-fontAdjust[data-size="xl"]').addClass(i));
  }),
  $(document).ready(function(){
    var a = $.fs_cookie.read("changeFontSize");
    var c = $('iframe').contents().find('html');
    if(null === a)
      return!1;
    if (c !== null)
        a.indexOf('128.6%') > -1 ? (c.css("font-size", "128.6%").addClass("is-fontSizeM"), e.removeClass(i), $('.js-fontAdjust[data-size="l"]').addClass(i)):
        a.indexOf('142.9%') > -1 && (c.css("font-size", "142.9%").addClass("is-fontSizeL"), e.removeClass(i), $('.js-fontAdjust[data-size="xl"]').addClass(i));
    a.indexOf('128.6%') > -1 ? (t.css("font-size", "128.6%").addClass("is-fontSizeM"), e.removeClass(i), $('.js-fontAdjust[data-size="l"]').addClass(i)):
    a.indexOf('142.9%') > -1 && (t.css("font-size", "142.9%").addClass("is-fontSizeL"), e.removeClass(i), $('.js-fontAdjust[data-size="xl"]').addClass(i));
  });
});

(function() {
	  function setElemTitle(gId) {

	    try{
	      disp.createItemMetaInfo();

	      var gIdUpp = gId.toUpperCase();
	      var gIdLow = gId.toLowerCase();

	      var colLit = eval("disp.get_metaInfo" + gIdUpp + "().columnList;");
	      var gpNumLast = eval("disp.get_" + gIdUpp + "_last();");
	      var gpNumFirst= eval("disp.get_" + gIdUpp + "_offset();");

	      for ( var i = 0; i < colLit.length; i++ ) {
	        var tagID = colLit[i];

	        for ( var j = gpNumFirst; j < gpNumLast; j++ ) {
	          var fld_id = gIdLow + '[' + j + '].sid' + tagID;
	          var fld_name = gIdLow + '[' + j + ']._' + tagID.toLowerCase() + '_str';

	          var elem = document.getElementById(fld_id);
	          var elem2 = document.getElementsByName(fld_name);

	          if(elem != undefined && elem2[0] != undefined) {
	        	  if (elem2[0].value != null && elem2[0].value != "") {
	                  elem.title = elem2[0].value;
	                }
	          }
	        }
	      }
	    } catch(e) {}
	    return true;
	  }
	  window.setElemTitleLib = window.setElemTitleLib|| {};
	  window.setElemTitleLib.setElemTitle = setElemTitle;
	})();

$(function() {
  var primerBtn = $('#primerBtn');
  primerBtn.click(function () {
    return openPrimerWin();
  });
});

function openPrimerWin() {
    var subWin;
    var w = window.screenX || window.screenLeft;
    var h = window.screenY || window.screenTop;
    var sts = 'height=768,width=1366,toolbar=no,menubar=no,toolbar=no,location=no,resizable=yes,scrollbars=no,left='+w+',top='+h;
    subWin = window.open('/manual/', 'manualWin', sts);
    subWin.blur();
    window.focus();
    window.blur();
    subWin.focus();
    return false;
}

/**
 * 画面上部変更箇所メッセージ表示・拡張/折畳処理
 * @isExpand 表示を広げるかどうか true-広げる false-折畳む
 */
function expandMessageChange(isExpand){
	// no message
	var mesList = getItemsById("messageLine_change");
	if( mesList == undefined ) return;

	// not singleline
	var mesExpand = getItemsById("messageExpand_change");
	if( mesExpand == undefined ) return;

	// one message
	var len = mesList.length;
	if( !isListItems(mesList)){
		getItemsById("messageLine_change",0).style.display= "" ;
		getItemsById("messageExpand_change",0).style.display= "none";
		getItemsById("messageCollapse_change",0).style.display= "none";
		return;
	}

	// multi message
	for (i = 0; i < len ; i++) {
		obj = mesList.item(i).style.display= isExpand ? "" : "none";
	}
	getItemsById("messageLine_change",0).style.display= "" ;
	getItemsById("messageExpand_change",0).style.display= isExpand ? "inline" : "none";
	getItemsById("messageCollapse_change",0).style.display= isExpand ? "none" : "inline";
}

/**
 * 戻る禁止
 */
addLoadEvent(backButtun);

function backButtun(){
    history.pushState(null, null, null);
    return true;
}

window.addEventListener("popstate", function() {
    history.pushState(null, null, null);
    return true;
});

/**
 * パスワード表示用アイコン挿入
 * @pwd パスワード項目ID
 * @btnNum ボタン連番
 */
function insEyeBtn(pwd,btnNum) {
	var pwdField = document.getElementById(pwd);

	if (pwdField != null) {
		pwdField.insertAdjacentHTML('afterend','<span id="eyeBtn' + btnNum + '" class="fa fa-eye" style="display:none"></span>');
		var eyeBtn = document.getElementById('eyeBtn' + btnNum);
		pwdField.addEventListener('focus', function() {
		   eyeBtn.style.display="inline";
		});
		pwdField.addEventListener('blur', function() {
		   eyeBtn.style.display="none";
		});

		eyeBtn.addEventListener('mouseover', function() {
			pwdField.type = "text";
		});
		eyeBtn.addEventListener('mouseout', function() {
			pwdField.type = "password";
		});
	}
	return true;
}
/**
 * パスワード表示チェックボックス挿入
 * @pwd パスワード項目ID
 * @boxNum チェックボックス連番
 */
function insPwdChkBox(pwd,boxNum) {
	var pwdField = document.getElementById(pwd);

	if (pwdField != null) {
		pwdField.insertAdjacentHTML('afterend','<input type="checkbox" id="password-check' + boxNum + '" > パスワードを表示する');
		var pwdCheckBox = document.getElementById('password-check' + boxNum);
		pwdCheckBox.addEventListener('change', function() {
		    if(pwdCheckBox.checked) {
		    	pwdField.setAttribute('type', 'text');
		    } else {
		    	pwdField.setAttribute('type', 'password');
		    }
		});
	}
	return true;
}

 /**
  * 必須項目のラベルに必須マークを追加する
  */
var requiredLabel = document.getElementsByClassName('label__REQUIRED');
var insertRequiredElem = '<span class="required-icon">必須</span>';
for(i = 0; i < requiredLabel.length; i++){
	// ラベルの子要素にHTMLを挿入
	requiredLabel[i].insertAdjacentHTML('beforeend', insertRequiredElem);
}

 /**
  * モバイルの必須項目のラベルに必須文字を追加する
  * @id ラベルのID
  */
function addRequiredLabelMobile(id){
	var targetElem = document.getElementById(id);
	var requiredElem = '<span class="required-icon-mobile">　必須</span>';
	targetElem.insertAdjacentHTML('beforeend', requiredElem);
}

 /**
  * モバイルのフォーマット説明文を追加する
  * @id ラベルのID
  * @text 説明文内容
  */
function addFormatDescriptionMobile(id, text){
	var targetElem = document.getElementById(id);
	var formatDescriptionElem = '<br><span class="format-description-mobile">' + text + '</span>'
	targetElem.insertAdjacentHTML('beforeend', formatDescriptionElem);
}

 /**
  * モバイルのプレースホルダーを追加する
  * @id ラベルのID
  * @text プレースホルダー内容
  */
 function addPlaceholderMobile(id, text) {
 	var targetElem = document.getElementById(id);
 	targetElem.placeholder = text;
 }
