function userFunc(){

	for (var i=0; i < $('*[id^="sidA_Y"]').length; i++) {
		$('*[id^="sidA_Y"]')[i].disabled = true;
	}
	return true;
}
addLoadEvent(userFunc);