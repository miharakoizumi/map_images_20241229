// global.js,v 1.47 2004/05/13 12:25:49 tsuruno Exp
var _global_js_load = false;

/**
 * 指定されたIDのエレメントを表示／非表示する。
 */
function toggleShow(elemid) {
  var elem = getItemById(elemid);
  if( elem.style.display=='none') {
    elem.style.display='block';
  } else {
    elem.style.display='none';
  }
}

/**
 * 指定されたIDのエレメントを非表示にする。
 */
function show(elemid) {
  var elem = getItemById(elemid);
  elem.style.display='block';
}

/**
 * 指定されたIDのエレメントを非表示にする。
 */
function hide(elemid) {
  var elem = getItemById(elemid);
  elem.style.display='none';
}

/**
 * 指定されたIDのエレメントが表示の場合showValueを、非表示の場合はhideValueを返す。
 */
function ifShow(elemid,showValue,hideValue) {
  if (getItemById('stacktrace').style.display=='none') {
    return hideValue;
  } else {
    return showValue;
  }
}

/**
 * タブを表示する。
 *
 * @param activeContentsID アクティブにするタブ内容ID
 * @param contentsIDList   同じタブグループのタブ内容ID
 */
function tabDraw(activeContentsID, contentsIDList) {
  for (i = 0; i < contentsIDList.length; i++) {
    if (activeContentsID == contentsIDList[i]) {
      tabActive(contentsIDList[i]);
    } else {
      tabInactive(contentsIDList[i]);
    }
  }
}

/**
 * タブをアクティブにする。
 *
 * @param contentsID タブ内容ID
 */
function tabActive(contentsID) {
  tabPaint(contentsID+'_label', contentsID, true );
}

/**
 * タブをイナクティブにする。
 *
 * @param contentsID タブ内容ID
 */
function tabInactive(contentsID) {
  tabPaint(contentsID+'_label', contentsID, false );
}

/**
 * タブを描画する。
 * 通常は tabDraw()を使用すること。
 *
 * @param labelID タブラベルのID
 * @param contentsID タブ内容のID
 * @param isActive アクティブかどうか
 */
function tabPaint(labelID, contentsID, isActive) {
  var label = getItemById(labelID);
  var contents = getItemById(contentsID);
  if( isActive ) {
	  label.className="tab_active";
	  if( contents.style.display=='none') {
	    contents.style.display='block';
	  }
  } else {
	  label.className="tab_inactive";
	  if( contents.style.display!='none') {
	    contents.style.display='none';
	  }
  }
}
/**
 * ドロップダウンリストボックスなどで値が変更された時
 */
function event_onChange(fieldName) {
	try {
		var elem = getSrcEventField();
		if(elem.type == "checkbox" || elem.type == "radio") {
			if(fieldName != oldFocus) {
				event_onFocus(fieldName);
			}
		}
	} catch (e) {}
	event_onBlur(fieldName);
	event_onFocus(fieldName);
}
/** フォーカスロスト時のフィールドを保持する */
var oldFocus = "";
/**
 * フォーカスが離れた時の処理
 */
function event_onBlur(fieldName) {
	if (fieldName == undefined) {
		fieldName = getSrcEventFieldName();
		oldFocus = fieldName;
	} else {
		oldFocus = fieldName;
	}
}

var blurCheckOK = true;
function event_onBlurAndCheck(ioItemCode, checkType, maxLength, maxScale) {
	blurCheckOK = true;
	var fieldName = getSrcEventFieldName();
	event_onBlur(fieldName);
	if (!isMobile()) {
		if(!isBlank(ioItemCode) && !isBlank(checkType)) {
			if (!checkBlur(fieldName, ioItemCode, checkType, maxLength, maxScale)) {
				blurCheckOK = false;
			}
		}
	}
	return blurCheckOK;
}

function checkAndResetBlurCheckResult() {
	if (!blurCheckOK) {
		blurCheckOK = true;
		return false;
	}
	return true;
}

function existActionField(fieldName, fieldList){
	if (fieldName != undefined) {
		var f = fieldName.indexOf("[");
		var r = fieldName.indexOf("]");
		var fstr = fieldName.substring(0,f);
		var rstr = fieldName.substring(r+1,fieldName.length);
		var str = fstr.concat(rstr);
		for (var i = 0; i < fieldList.length; i++){
			if (str==fieldList[i]) {
				return true;
			}
		}
	}
	return false;
}

var actionShortCut = false;
/**
 * フォーカス時処理
 *
 * @param fieldName
 * @param nextFieldName(for file)
 * @param fieldNameStr(for file)
 * @param fromName 対象フォームのname
 */
function event_onFocus(fieldName, nextFieldName, fieldNameStr, formName) {
	if (isScreenLock()){
		if (!_global_isMSIE) {
			window.focus();
		}
		return;
	}
	if (fieldName == undefined) {
		fieldName = getSrcEventFieldName();
	}
//	document.forms[0]._focus.value = (nextFieldName != undefined) ? nextFieldName : fieldName;
	getForm(formName)._focus.value = (nextFieldName != undefined) ? nextFieldName : fieldName;
	if ((existActionField(fieldName,getActionField()) && !key_tabPressed) || actionShortCut) {
		actionShortCut = false;
		return; // アクションのときは更新しない
	}
	if (oldFocus != "") {
		if (isChangeField(oldFocus, disp._isAsync/*ignore file*/)) {
			var fieldList = getChioceRefField();
			if (fieldRefCheck(fieldName)){
				var tmpOldFocus = convFormToFieldNameStr(oldFocus);
				if (fieldNameStr != undefined && !disp._isAsync ) {
					tmpOldFocus = tmpOldFocus + "," + fieldNameStr;
				}
				if (!isScreenLock()){
					if(disp._isAsync){
						asyncAction("event_FieldChange", tmpOldFocus, _globalMsgObject.doRedraw, doRedraw);
					}else{
						_checkField = ""; // 同期再描画する（画面が切り替わる）ので、これ以上JS組込チェックを行わない
						buttonAction("event_FieldChange", tmpOldFocus, _globalMsgObject.doRedraw);
					}
				}
			}
			oldFocus = "";
		}
	}
}

/**
 * 非同期通信オブジェクト作成
 *
 * @param action
 * @param param
 * @param msg
 */
function createXMLHttpRequest(){
	try {
		return new XMLHttpRequest();
	} catch (e) {
		try {
			return new ActiveXObject("Msxml2.XMLHTTP") ;
		} catch (e) {
			try {
				return new ActiveXObject("Microsoft.XMLHTTP") ;
			} catch (e2) {
				return null ;
			}
		}
	}
}
/**
 * 非同期送信処理
 *
 * @param method -> POST or GET
 * @param url -> request URL
 * @param async -> is async ?
 * @param func -> callback function. Signature is (String responseText, Error error)
 * @param params -> request parameters
 * @param encoding -> charcter encoding
 */
function sendRequest(method,url,async,func,params,encoding){
	var xmlhttp = createXMLHttpRequest();
	if( xmlhttp == null ) throw new Error(_globalMsgObject.createRequest);
	xmlhttp.onreadystatechange = function() {
		var err = null;
		var data="";
		if (xmlhttp.readyState == 4) {
			if (xmlhttp.status == 200) {
				try{
					// システムエラーチェック
					data=xmlhttp.responseText;
				} catch (e) {
					err=e;
				}

				var callButton = document.createElement('input');
				callButton.type = 'button';
				callButton.style.display = 'none';
//				document.forms[0].appendChild(callButton);
				getForm().appendChild(callButton);
				callButton.onclick = function() {
					if (typeof func == 'string') {
						eval(func);
					} else {
						func(data,err);
					}
//					document.forms[0].removeChild(callButton);
					getForm().removeChild(callButton);
				};
				callButton.click();
			}else{
				var message = _globalMsgObject.serverError+' status='+xmlhttp.status;
				if (!isBlank(xmlhttp.statusText)) {
					message = message + " message=" + xmlhttp.statusText;
				}
				err = new Error(message);
				err.name = 'ServerError';
				if (typeof func == 'string') {
					eval(func);
				} else {
					func(data,err);
				}
			}
			xmlhttp = null;
		}
	}
	if(params == undefined || params == ''){
		params = '';
	}else{
		params = params+ "&_async_="+(new Date()).getTime();// prevent cash
	}
	if(method.toUpperCase() == 'GET'){
		url += ('?'+params);
	}
	xmlhttp.open(method, url, async);
	xmlhttp.setRequestHeader("Content-Type", "application/x-www-form-urlencoded;charset="+encoding);
	xmlhttp.setRequestHeader("X-Requested-With", "XMLHttpRequest");
	xmlhttp.send( params );
}
/**
 * 非同期アクション処理
 *
 * @param action
 * @param param
 * @param msg
 */
function asyncAction(action, param, msg, func, async ) {
	showStatusBar(msg);
	try {
		var url = disp.form.action;
		var fixParams =
			('method=' + action) +
			('&param=' + param);
		var params = disp.serialize(param);
		if(async==undefined) async=true;
		if (action == "event_FieldChange") {
			_asyncActionProcessing = true; // _AsyncDisp.jsp内でfalseになる
		}
		sendRequest("POST",url,async,func,fixParams+params,disp._encoding);
	} catch (e) {
		showStatusBar(e.message,"ERROR");
		_asyncActionProcessing = false;
	}
	return false;
}

/**
 * 画面再描画を実行。
 *
 * @param jsonData
 * @param err
 */
function doRedraw(jsonData,err){
	if(err!=null){
		showStatusBar(err.message,"ERROR");
		return ;
	}
	eval(jsonData);
	disp.setData(_dispData);
	showStatusBar("");

	refocusRadio();
	refocusPulldown();

	if(_multiBoxData!=null){
		setMultiBoxData(_multiBoxData);
	}
	if (isHTML5() || !_global_isMSIE) {
		init_table();
		adjust_label();
	}
}

/**
 * テーブルのheightを削除
 */
function init_table() {
	var tables = document.getElementsByTagName("table");
	for(var i=0;i<tables.length;i++){
		var table = tables[i];
		var style;
		var tableClass;
		var array;
		var ret;
		if(table.hasAttribute("class")){
			tableClass = table.getAttribute("class");
			if(tableClass.match(/^article$/)){
				if((_global_isMSIE && getIEVer() <= 10) || _global_isMSEDGE) {
					var trs = table.getElementsByTagName("tr");
					for (r = 0; r < trs.length; r++) {
						var tds = trs[r].getElementsByTagName("td");
						for (d = 0; d < tds.length; d++) {
							if (tds[d].getElementsByTagName("label")) {
								tds[d].style.height = "";
								continue;
							}
						}
					}
				} else {
					if(table.hasAttribute("style")){
						style = table.getAttribute("style");
						if(style.indexOf("height") !== -1) {
							array = style.split(";");
							for(var index in array) {
								if(array[index].indexOf("height") === -1) {
									ret = array[index] + ";";
								}
							}
						}
						if(ret) {
							table.setAttribute("style",ret);
						} else {
							table.removeAttribute("style");
						}
					}
				}
			}
		}
	}
}

/**
 * ラベルの調整
 *
 */
function adjust_label() {
	var tables = document.getElementsByTagName("table");
	for (var i = 0; i < tables.length; i++) {
		var table = tables[i];
		var style;
		var tableClass;
		if (table.hasAttribute("class")) {
			tableClass = table.getAttribute("class");
			if (tableClass.match(/^article$/)) {
				if ((_global_isMSIE && getIEVer() <= 10) || _global_isMSEDGE) {
					var trs = table.getElementsByTagName("tr");
					for (var r = 0; r < trs.length; r++) {
						var h = trs[r].clientHeight;
						var tds = trs[r].getElementsByTagName("td");
						for (d = 0; d < tds.length; d++) {
							if (tds[d].getElementsByTagName("label")) {
								tds[d].style.height = h + "px";
								continue;
							}
						}
					}
				} else {
					if (table.hasAttribute("style")) {
						style = table.getAttribute("style");
						if (style.indexOf("height") !== -1) {
							style = style + ";height:" + table.clientHeight + "px";
						}
					} else {
						style = "height:" + table.clientHeight + "px";
					}
					table.setAttribute("style", style);
					if(_global_isFIREFOX) {
						var trs = table.getElementsByTagName("tr");
						for (var r = 0; r < trs.length; r++) {
							trs[r].style.height = "100%";
						}
					} else if(_global_isCHROME || _global_isSAFARI) {
						var trs = table.getElementsByTagName("tr");
						for (var r = 0; r < trs.length; r++) {
//							trs[r].style.height = "100%";
							var tds = trs[r].getElementsByTagName("td");
							for (d = 0; d < tds.length; d++) {
									tds[d].style.height = "100%";
							}
						}
					}
				}
			}
		}
	}
}

/**
 * 複数選択リストボックスの値を設定する。
 * 選択値が可視エリアにくるための処置。
 */
function setMultiBoxData( data ){
	window.setTimeout(function(){
		try{
			disp.setData(data);
		}catch(e){
			disp._isRedraw = false;
		}
	},0);
}

/**
 * フィールドの前回値を取得する。
 *
 * @param elem フォーム要素
 */
function getFormPreviousValue(elem){
	var val;
	if ("text" == elem.type || "hidden" == elem.type || "password" == elem.type || "TEXTAREA" == elem.tagName || "file" == elem.type) {
		val =  elem.defaultValue;
		//IEでは\r\nが\rに変更されてしまう事象に対応
		//比較の時のみ変換
		val = normalizeCRLF(val);
	} else if ("checkbox" == elem.type) {
		val =  elem.defaultChecked;
	} else if ("radio" == elem.type) {
		val =  elem.value;
	} else if ("select-one" == elem.type) {
		var opts = elem.options;
		var numOpts = opts.length;
		for (var j = 0; j < numOpts; j++) {
			var opt = opts[j];
			if (opt.defaultSelected){
				val = opt.value;
				break;
			}
		}
	} else if ("SELECT" == elem.tagName) {
		var opts = elem.options;
		var numOpts = opts.length;
		for (var j = 0; j < numOpts; j++) {
			var opt = opts[j];
			if (opt.defaultSelected){
				val = opt.value;
				break;
			}
		}
	} else if (elem.length > 0) {
		// ラジオボタンの配列の時
		var num = elem.length;
		for (var j = 0; j < num; j++) {
			var e = elem[j];
			if ("radio" == e.type) {
				if (e.defaultChecked){
					val = e.value;
					break;
				}
			}
		}
	}
	return val;
}

/**
 * フィールドの今回値を取得する。
 *
 * @param elem フォーム要素
 */
function getFormCurrentValue(elem){
	var val;
	if ("text" == elem.type || "hidden" == elem.type || "password" == elem.type || "TEXTAREA" == elem.tagName || "file" == elem.type) {
		val = elem.value;
		//IEでは\r\nが\rに変更されてしまう事象に対応
		//比較の時のみ変換
		val = normalizeCRLF(val);
	} else if ("checkbox" == elem.type ) {
		val = elem.checked;
	} else if ("radio" == elem.type) {
		val = elem.value;
	} else if ("select-one" == elem.type) {
		var opts = elem.options;
		var numOpts = opts.length;
		for (var j = 0; j < numOpts; j++) {
			var opt = opts[j];
			if (opt.selected){
				val = opt.value;
				break;
			}
		}
	} else if ("SELECT" == elem.tagName) {
		var opts = elem.options;
		var numOpts = opts.length;
		for (var j = 0; j < numOpts; j++) {
			var opt = opts[j];
			if (opt.selected){
				val = opt.value;
				break;
			}
		}
	} else if (elem.length > 0) {
		// ラジオボタンの配列の時
		var num = elem.length;
		for (var j = 0; j < num; j++) {
			var e = elem[j];
			if ("radio" == e.type) {
				if (e.checked){
					val = e.value;
					break;
				}
			}
		}
	}
	return val;
}


/**
 * フィールド変更有無を検証する。
 *
 * @param fieldName フォームのname属性
 */
function isChangeField(fieldName, ignoreFile){
	var elem = disp.form[fieldName];
	if (elem == undefined) return false;
	if (ignoreFile == undefined) ignoreFile = false;

	if ("file" == elem.type && ignoreFile) return false;

	// 前回の値
	var preVal = disp._previousValues[fieldName]; // まずキャッシュを見る
	if(preVal==undefined){ // キャッシュになければ要素より取得
		preVal = getFormPreviousValue(elem);
		disp._previousValues[fieldName] = preVal;
	}

	// 現在の値
	var nowVal = getFormCurrentValue(elem);
	//比較
	if(nowVal != preVal){
		return true;
	}
	return false;
}


/**
 * フィールド名がファイル項目のファイルフォームであるかを判断します。
 * @param fieldName フィールド名
 */
function isNameFormfile(fieldName) {
	if (fieldName == undefined) {
		return false;
	}
	if (fieldName == "") {
		return false;
	}
	var r = fieldName.indexOf("].");
	var rstr = fieldName;
	if (r >= 0) {
		rstr = fieldName.substring(r+2,fieldName.length);
	}

	if ( rstr.charAt(0) == "_" ) {
		var lastidx = rstr.lastIndexOf("formfile");
		if(lastidx < 0) {
			return false;
		}
		var len = rstr.length - lastidx - 1 ;
		if ( len != 7 ) {// 7 = "formfile".length
			return false;
		}
	} else {
		return false;
	}
	return true;
}

/**
 * ファイルフォームのフィールド名を通常のフィールド名(_XXX_str)に変更します。
 * @param fieldName フィールド名
 */
function convFormToFieldNameStr(fieldName) {
	if (isNameFormfile(fieldName)) {
		var lastidx = fieldName.lastIndexOf("formfile");
		var fieldstr = fieldName.substring(0,lastidx);
		fieldstr = fieldstr + "_str";
		return fieldstr;
	}
	return fieldName;
}

/**
 * 画面再評価処理(Validationせず、全項目をフォーマット)
 * @param fieldName
 * @param isAsync XHRを使用するか
 * @param isXHRAsync XHRを非同期モードで動作させるか
 */
function event_atnone(fieldName,isAsync,isXHRAsync) {
	if(isAsync){
		if(isXHRAsync==undefined) isXHRAsync = true;
		asyncAction("event_FieldChange", fieldName, _globalMsgObject.doRedraw, doRedraw, isXHRAsync);
	}else{
		buttonAction("event_FieldChange", fieldName, _globalMsgObject.doRedraw);
	}
}

/* 事前メッセージ結果保持変数 */
var _preMSG_ = false;
/**
 *事前メッセージの結果を返す。
 *
 * @param fieldName フィールド名
 */
function getResultPreMSG(fieldName) {

	if (fieldName == undefined) {
		fieldName = getSrcEventFieldName();
	}
	var field = getMsgRefField();
	if (field[fieldName] != undefined) {
		// 事前メッセージを表示する
		if (!confirm(field[fieldName])) {
			return false;
		}
	}
	_preMSG_ = true;
	return true;
}

/**
 * ボタンが押されたときの処理
 *
 * @param fieldName フィールド名
 * @param action Action名
 * @param param パラメータ
 * @param rowIdx 行番号
 * @param fromName 対象フォームのname
 */
function event_onClick(fieldName, action, param, rowIdx, formName){
	if(!getResultPreMSG(fieldName)) return;

	buttonAction(action, createTriggerInfo(), _globalMsgObject.sending, rowIdx, formName);
}

/**
 * ボタンが押されたときの処理
 *
 * @param fieldName フィールド名
 * @param action Action名
 * @param param パラメータ
 * @param rowIdx 行番号
 * @param fromName 対象フォームのname
 */
function event_onClick_withDirtycheck(fieldName, action, param, rowIdx, formName){
	if(!getResultPreMSG(fieldName)) return;

	buttonActionWithDirtycheck(action, createTriggerInfo(), _globalMsgObject.sending, rowIdx, formName);
}

/**
 * OldFocusを検証してトリガ情報を作成します。
 */
function createTriggerInfo(){
	if(!disp._isRecalc) return "";
	var tmpOldFocus="";
	if (oldFocus != "" && isChangeField(oldFocus) && fieldRefCheck(oldFocus) ) {
		tmpOldFocus = convFormToFieldNameStr(oldFocus);//convert for file
	}
	return tmpOldFocus;
}

/**
 * ボタンが押されたときの処理(新規ウィンドウを開く)
 *
 * @param fieldName フィールド名
 * @param action Action名
 * @param param パラメータ
 * @param rowIdx 行番号
 */
function event_onClick_withOpenWindow(fieldName, action, param, rowIdx){
	// 新規ウィンドウ開く
	return sub_event_onClick_withTARGET(fieldName, action, param, rowIdx, "_blank");
}
/**
 * ボタンが押されたときの処理(IFRAMEに開く)
 *
 * @param fieldName フィールド名
 * @param action Action名
 * @param param パラメータ
 * @param rowIdx 行番号
 */
function event_onClick_withIFrame(fieldName, action, param, rowIdx){
	// IFRAMEに開く(@see io_frame.jsp.00.vm)
	return sub_event_onClick_withTARGET(fieldName, action, param, rowIdx, "_ifrm");
}
/**
 * onClickサブ
 */
function sub_event_onClick_withTARGET(fieldName, action, param, rowIdx, target){
	if (isScreenLock()){
		return false;
	}
	if(!getResultPreMSG(fieldName)) return false;

	// 現在のFORMのTARGETを一時保存
//	_old_target = document.forms[0].target;
	_old_target = getForm().target;
	// ターゲットを新規ウィンドウ
//	document.forms[0].target = target;
	getForm().target = target;

	if(!(_global_isMSIE || _global_isMSEDGE)) {
		setExportState(true);
	}

	// ボタン処理
	buttonAction4AnotherTarget(action, param, _globalMsgObject.sending, rowIdx);
	// 処理待ち設定
	setTimeout(sub_event_click_waitready, 3000);
	_waitTarget = target;
	return true;
}
var _old_target = "";
var _waitTarget = "";
function sub_event_click_waitready() {
	if(_global_isMSIE || _global_isMSEDGE) {
		var targetFrame = getItemById(_waitTarget);
		if (!targetFrame) {
			if (document.getElementsByName(_waitTarget).length > 0) {
				targetFrame = document.getElementsByName(_waitTarget)[0];
			}
		}

		// window.status = getItemById(_waitTarget).readyState;
	//	if (getItemById(_waitTarget)) {
		if (targetFrame) {
	//		if (getItemById(_waitTarget).readyState == "loading") {
			if (targetFrame.contentWindow.document.readyState == "loading") {
				setTimeout(sub_event_click_waitready, 3000);
				return;
			}
		}
	} else {
		if (getExportState() == "loading") {
			setTimeout(sub_event_click_waitready, 3000);
			return;
		}
		setExportState(false);
	}

	clearTimeout(sub_event_click_waitready);
	// 送信中を消す
	clearSendMsg();
	clear_ScreenLock();
	// カーソルを戻す
	document.body.style.cursor = "auto";
	// ステータス行クリア
	showStatusBar("");
	// ターゲットを元に戻す
//	document.forms[0].target = _old_target;
	getForm().target = _old_target;
	// スクリーンロック解除
	setScreenLock(false);
}
/**
 * ボタンが押されたときの処理(CSVファイル出力)
 *
 * @param fieldName フィールド名
 * @param action Action名
 * @param param パラメータ
 * @param rowIdx 行番号
 * @param ioCode 印刷アクション・入出力コード
 * @param ioItemCode 印刷アクション・入出力項目コード
 * @param ioItemPropName 印刷アクション・入出力項目プロパティ名
 * @param preaction 印刷アクション・印刷前実行アクションコード
 * @param index 印刷アクション・行番号
 */
function event_onClick_PrintFile(fieldName, action, param, rowIdx, ioCode, ioItemCode, ioItemPropName, preaction, index){
	_print_iocode = ioCode;
	_print_ioitemcode = ioItemCode;
	_print_ioitempropname = ioItemPropName;

	if (isScreenLock()){
		return false;
	}
	if(!getResultPreMSG(fieldName)) return false;

	if(doPrintPreaction(ioItemCode, preaction, index)){
		return;
	}

	// 現在のFORMのTARGETを一時保存
//	_old_printtarget = document.forms[0].target;
	_old_printtarget = getForm().target;
	// ターゲットを新規ウィンドウ
//	document.forms[0].target = "_ifrm";
	getForm().target = "_ifrm";
	// ボタン処理
	buttonAction4AnotherTarget(action, param, _globalMsgObject.sending, rowIdx);
	//PopUpBlock対応
	if(!(_global_isMSIE || _global_isMSEDGE)) {
		var w_target = document.forms[ioItemCode+'_form'].target;
		if(w_target == "_blank") w_target = w_target + "_iw";
		if(w_target.length != 0) {
			if(w_target != '_self') {
				window.open('',w_target);
			}
		}
	}
	// 処理待ち設定
	setTimeout(sub_event_click_fileprint, 3000);
	_wait_printtarget = "_ifrm";
}
var _print_iocode = "";
var _print_ioitemcode = "";
var _print_ioitempropname = "";
var _old_printtarget = "";
var _wait_printtarget = "";

function sub_event_click_fileprint() {
	var outputCsv = false;
	var targetFrame = getItemById(_wait_printtarget);
	if (!targetFrame) {
		if (document.getElementsByName(_wait_printtarget).length > 0) {
			targetFrame = document.getElementsByName(_wait_printtarget)[0];
		}
	}

	if (targetFrame) {
		if (targetFrame.contentWindow.document.readyState == "loading") {
			setTimeout(sub_event_click_fileprint, 3000);
			return;
		}
		var target = document.forms[_print_ioitemcode + '_form']['fm-fielddatafilename'];
		if (targetFrame.contentWindow.document.getElementById("_exportFileName")) {
			outputCsv = true;
			target.value = targetFrame.contentWindow.document.getElementById("_exportFileName").value;
		}
	}
	clearTimeout(sub_event_click_fileprint);
	// 送信中を消す
	clearSendMsg();
	clear_ScreenLock();
	// カーソルを戻す
	document.body.style.cursor = "auto";
	// ステータス行クリア
	showStatusBar("");
	// ターゲットを元に戻す
//	document.forms[0].target = _old_printtarget;
	getForm().target = _old_printtarget;
	// スクリーンロック解除
	setScreenLock(false);
	if(outputCsv) {
		var formName = _print_ioitemcode + '_form';
		var propName = _print_ioitempropname;
		var methodName = 'doPrint_'+_print_ioitemcode;
		eval(methodName+"("+"'"+formName+"',disp,"+"'"+propName+"'"+")");
	}

}

/** TABキーが押下されたかフラグ */
var key_tabPressed = false;
/** 複数チェックボックス移動中にWindowのスクロールを動かさない */
var keyDownCansel = false;
/** サジェスト用入力監視 */
var _suggestObserver = null;
/**
 * キー押下イベント処理
 * ファンクションキーショートカット設定のある画面では、オーバーライドされる。
 */
function event_onKeyDown() {
	_onkey_press = false;
	var keyCode = getKeyCode();
	if (keyCode == 9 || keyCode == 13) {
		key_tabPressed = true;
	} else {
		key_tabPressed = false;
	}
	if (!key_tabPressed) {
		if (_suggestObserver) {
			_suggestObserver.startTimer();
		}
	}
	if(keyCode == 9 || keyDownCansel){
		keyDownCansel = false;
		return false;
	} else {
		return true;
	}
}
/**
 * キーコード取得
 */
function getKeyCode() {
	return (window.event.keyCode ? window.event.keyCode : window.event.charCode);
}
function setKeyCode(code) {
	window.event.keyCode = code;
	window.event.charCode = code;
}

var _keyDownKeyCode = "";
var _inIME = false;
function event_onKeyDown4Item(code) {
	cursor_onKeyDown(code);
	// HTML5のIEではIME変換中にも下キーのkeyDownイベントが発生する
	// （KeyCode 229→40 が連続）
	// suggestを反応させないようIME変換中フラグを立てる
	_inIME = false;
	if (_keyDownKeyCode == 229) {
		if (getKeyCode() == 40) {
			_inIME = true;
		}
	}

	_keyDownKeyCode = getKeyCode();

	return true;
}

function inIME(clear, keyUpKeyCode) {
	if (!(_global_isMSIE && isHTML5())) {
		return false;
	}
	var result = _inIME;
	if (keyUpKeyCode == 13 && _keyDownKeyCode != 13) {
		result = true;
	}
	if (clear) {
		_inIME = false;
		_keyDownKeyCode = "";
	}
	return result;
}

function isNonPrintableCodePressed() {
	if (_global_isMSIE) {
		if (window.event.keyCode == 27) { // Escキー
			return true;
		}
	} else {
		if (window.event.keyCode == 13) { // Enterキー(charCode == 0)
			return false;
		}
		if (window.event.charCode == 0) { // 制御キーを入力
			return true;
		}
	}
	if (window.event.ctrlKey || window.event.altKey || window.event.metaKey) {
		return true;
	}
	return false;
}

function event_onKeyPress4Item(code, checkFuncName) {
	if( isNonPrintableCodePressed() ){
		return true;
	}

	if(checkFuncName != undefined && checkFuncName != null && checkFuncName != "") {
		var res = eval(checkFuncName + "()");
		if(res == false) return false;
	}

	if (getKeyCode() == 13 && isKeyPressInvalidItem(getSrcEventField())) {
		return false;
	}
	return true;
}
/** _onkey_pressはkeyUpで初期化される */
var _onkey_press = false;
var _noInput = false;
function event_onKeyPress() {
	if( isNonPrintableCodePressed() ){
		return true;
	}

	_onkey_press = true;
	if(_noInput) {
		_noInput = false;
		return false;
	} else if (getKeyCode() == 13 && isKeyPressInvalidItem(getSrcEventField())) {
		return false;
	}
	return true;
}
function isKeyPressInvalidItem (item) {
	var type = item.type;
	if (isBlank(type)) return false;
	if (type == "text"
		 || type == "checkbox"
		 || type == "select-one"
		 || type == "radio"
		 || type == "select-multiple"
		 || type == "password"
		 || type == "file") {
		return true;
	}
	return false;
}

/**
 * フィールドの関連があるかチェックする
 * @param fieldName フィールド名
 */
function fieldRefCheck(fieldName) {
	return (
		   existField(oldFocus, getChioceRefField())
		|| existField(oldFocus, getDefalutValueRefField())
		|| existField(oldFocus, getStatementRefField())
		|| existField(oldFocus, getConditionRefField())
		|| existField(oldFocus, getFieldTypeRefField())
		);
}

/**
 * フィールドリストに検索フィールド名が存在するかチェック
 * @param fieldName 検索フィールド名
 * @param fieldList フィールドリスト
 * @return true=存在する,false=存在しない
 */
function existField(fieldName, fieldList){
	// grp[].field形式のフィールド名からfieldを抽出
	if ((n = fieldName.lastIndexOf(".")) != -1) {
	    fieldName = fieldName.substring(n+1);
	}
	for (var i = 0; i < fieldList.length; i++){
		if (fieldName==fieldList[i]) {
			return true;
		}
	}
	return false;
}

/** 画面ロック状態変数 */
var _screenLock = false;
/**
 * 画面ロック状態取得
 */
function isScreenLock() {
	return _screenLock;
}
/**
 * 画面ロックセット
 */
function setScreenLock(lock) {
	_screenLock = lock;
	if(!lock) {
		dispatchRemoveEventListener("scroll", resize_ScreenLock, false);
	}
}
/**
 * Action処理
 *
 * @param action Action名
 * @param param パラメータ
 * @param msg 表示メッセージ
 * @param rowIdx 行番号
 * @param fromName 対象フォームのname
 */
function buttonAction(action, param, msg, rowIdx, fromName) {
	if (pre_submit(action, param, msg, rowIdx, fromName)) {
		submitForm(fromName);
	}
	return false;
}
function buttonAction4AnotherTarget(action, param, msg, rowIdx) {
	if (pre_submit(action, param, msg, rowIdx)) {
		setTimeout(submitForm, 0);
	}
	return false;
}
function pre_submit(action, param, msg, rowIdx, fromName) {
	// 二度押し防止(ボタン無効化)
	if (isScreenLock()){
		alert(_globalMsgObject.nowSending);
		return false;
	} else {
		setScreenLock(true);
		document.body.style.cursor = "wait";
	}
	if (msg == undefined) {
		msg = _globalMsgObject.sending;
	}
	disp_ScreenLock();
	sendMsg();
	showStatusBar(msg);
//	document.forms[0].method.value = action;
	getForm(fromName).method.value = action;
//	document.forms[0].param.value = param;
	getForm(fromName).param.value = param;
	var pos = getDispPos();
//	document.forms[0]._posx.value = pos["x"];
	getForm(fromName)._posx.value = pos["x"];
//	document.forms[0]._posy.value = pos["y"];
	getForm(fromName)._posy.value = pos["y"];
//	document.forms[0]._rowidx.value = rowIdx;
	getForm(fromName)._rowidx.value = rowIdx;
	setGroupScrollTop();
	setDataGridString();
//	document.forms[0].elements["_timezoneOffset"].value = new Date().getTimezoneOffset();
	getForm(fromName).elements["_timezoneOffset"].value = new Date().getTimezoneOffset();
//	var actURL = document.forms[0].action;
	var actURL = getForm(fromName).action;
	var actIdx = actURL.indexOf('?_Action_=');
	if(actIdx != -1) {
		actURL = actURL.substring(0, actIdx);
	}
//	document.forms[0].action = actURL + '?_Action_=' + action;
	getForm(fromName).action = actURL + '?_Action_=' + action;
	return true;
}
function submitForm(fromName){
	try {
//		document.forms[0].submit();
		getForm(fromName).submit();
	} catch (e) {
		alert(_globalMsgObject.sendError);
		document.body.style.cursor = "";
		setScreenLock(false);
		clearSendMsg();
		clear_ScreenLock();
		showStatusBar(e,"ERROR");
	}
}
/**
 * 更新有無検証付きAction処理
 *
 * @param group Group名
 * @param action Action名
 * @param param パラメータ
 * @param msg 表示メッセージ
 * @param rowIdx 行番号
 * @param fromName 対象フォームのname
 */
function buttonActionWithDirtycheck( action, param, msg, rowIdx, fromName) {
	if (!dirtyCheck()) return;
	buttonAction(action, param, msg, rowIdx, fromName);
}

/**
 * 更新有無検証
 *
 * @return true=変更がないor変更破棄する false=変更破棄しない
 */
function dirtyCheck() {
	var isDirty = disp.isDirty();
	if( isDirty ){
		if (!confirm(_globalMsgObject.chgReset)) return false;
	}
	return true;
}

/**
 * フォームのフィールドが変更されているかどうか
 * @param form フォーム
 * @return 1つでも変更されている=true, 変更されていない=false
 */
function isDirty(form) {
	var numElems = form.elements.length;
	for (var i = 0; i < numElems; i++) {
		var elem = form.elements[i];
		if ("text" == elem.type || "TEXTAREA" == elem.tagName) {
			if (elem.value != elem.defaultValue) return true;
		} else if ("checkbox" == elem.type || "radio" == elem.type) {
			if (elem.checked != elem.defaultChecked) return true;
		} else if ("SELECT" == elem.tagName) {
			var opts = elem.options;
			var numOpts = opts.length;
			for (var j = 0; j < numOpts; j++) {
				var opt = opts[j];
				if (opt.selected != opt.defaultSelected) return true;
			}
		}
	}
	return false;
}
/**
 * フォーカスをどこに当てるのかを判定し、フォーカスをセットする。
 *
 * @param fieldName:フォーカスを当てるフィールド名
 */
function focusControl(fieldName){
	try {
//		var focusControl = document.forms[0].elements[fieldName];
		var focusControl = getForm().elements[fieldName];
		if (focusControl.type != "hidden") {
			focusControl.focus();
			focusControl.scrollIntoView();
		}
	} catch (e) {
		// do nothing
	}
}
/**
 * フィールドを選択状態にする。
 *
 * @param form     :フォーム
 * @param fieldName:選択状態にするフィールド名
 */
function selectText(form,fieldName){
	try {
//		var elem = document.forms[0].elements[fieldName];
		var elem = getForm().elements[fieldName];
		if (elem != undefined) {
			if (elem.type == "text") {
				selectTextRange(form[fieldName], true);
			}
		}
	} catch (e) {
		// do nothing
	}
}

/**
 *　イベントの発生したエレメントのnameの値を取得する。
 */
function getSrcEventFieldName(){
	var eventSrc = getSrcEventField();
	if(eventSrc.tagName && eventSrc.tagName.toLowerCase() == 'span'){
		if(eventSrc.className.indexOf('icon') != -1){
			if(eventSrc.parentNode.parentElement.tagName.toLowerCase() == 'button'){
				eventSrc = eventSrc.parentNode.parentElement;
			}
		}else{
			if(eventSrc.parentNode.tagName.toLowerCase() == 'button') {
				eventSrc = eventSrc.parentElement;
			}
		}
	}
	return (eventSrc.name ? eventSrc.name : eventSrc.id);
}
function getSrcEventField() {
	return (window.event.srcElement ? window.event.srcElement : window.event.target);
}

/**
 * ChoiceDialogイベントハンドラ
 * @fieldName 選択フィールド名
 * @actionName 選択ダイアログ名
 * @dlgFeatures ダイアログフィーチャ
 * @btnName 選択ダイアログ表示ボタン名
 */
function onDlgBtnClick(fieldName, actionName, dlgFeatures, btnName, func){
	if (isScreenLock()) return; // 送信中であれば表示しない。
	var args = new Object();
//	args._wfinfo = document.forms[0]._wfinfo;
	args._wfinfo = getForm()._wfinfo;
	args._do = getContextPath() + actionName + ".do";
//	ret = showDialogPreventInput(getContextPath() + "/page/_sysDialog.jsp?do=" + getContextPath() + actionName + ".do", args, dlgFeatures);
	showDialog(getContextPath() + "/page/_sysDialog.jsp", args, dlgFeatures);
	_dialogCallBack = function(ret) {
		recoverFocus(btnName);
		if (ret != undefined){
//			document.forms[0][fieldName].value = ret["value"];
			getForm()[fieldName].value = ret["value"];
			// Optionの項目を消去
//			while (0 < document.forms[0][fieldName].options.length){
			while (0 < getForm()[fieldName].options.length){
//				document.forms[0][fieldName].options[0] = null;
				getForm()[fieldName].options[0] = null;
			}
			// 選択値を追加
			var dispText = ret["disp"].replace(new RegExp("\n", "gm"),'');
			dispText = dispText.replace(new RegExp("\r +", "gm"),' ');
			dispText = dispText.replace(new RegExp("\r", "gm"),' ');
//			document.forms[0][fieldName].options[0] = new Option(dispText, ret["value"]);
			getForm()[fieldName].options[0] = new Option(dispText, ret["value"]);

			// hidden value set
			var dispField = fieldName.replace("str", "choicelist");
			var hiddenLabel = dispField + "[0].label";
//			if (document.forms[0][hiddenLabel] != undefined){
			if (getForm()[hiddenLabel] != undefined){
//				document.forms[0][hiddenLabel].value = ret["disp"];
				getForm()[hiddenLabel].value = ret["disp"];
			}
			var hiddenValue = dispField + "[0].value";
//			if (document.forms[0][hiddenValue] != undefined){
			if (getForm()[hiddenValue] != undefined){
//				document.forms[0][hiddenValue].value = ret["value"];
				getForm()[hiddenValue].value = ret["value"];
			}
			func();
		}
	}
}

/**
 * 複数選択ダイアログ表示
 * @toIoName ダイアログで表示するIOCODE
 * @fromIoName ダイアログを表示するIOCODE
 * @actName ダイアログ表示アクション名
 * @fieldNames NextIoParamフィールドID（カンマ区切り複数）
 * @strFieldNames NextIoParamフィールドID・_str系（カンマ区切り複数）
 * @gName 動作したアクションの所属グループ
 * @buttonIndex ボタンインデックス
 * @buttonName ボタン名
 */
function onDlgBtnClickMultiDialog( toIoName, fromIoName, actName, fieldNames, strFieldNames, fieldName, dlgFeatures, gName, dialogoptimize, buttonIndex, buttonName ){
	if (isScreenLock()) return; // 送信中であれば表示しない。
	if(!getResultPreMSG(fieldName)) return;

	// ダイアログ引数生成
//	document.forms[0]._rowidx.value = buttonIndex;
	getForm()._rowidx.value = buttonIndex;
	if(dialogoptimize) {
		var param = disp.serializeDialogParam(gName);
		param = param + ('&_dialog_io=' + toIoName)
				+ ('&_dialog_opener_io=' + fromIoName)
				+ ('&_dialog_opener_action=' + actName)
				+ ('&_fieldNames=' + disp._encodeParam(fieldNames))
				+ ('&_dlgFeatures=' + disp._encodeParam(dlgFeatures));
		dialogAction(param, buttonName);
	} else {
		var args = new Array();
		//showModalDialogにフォームを渡す
		if (!(!isHTML5() && isMSIE())) {
			var targetForm = getForm();
			updateAllDOMFields(targetForm);
			args[0] = targetForm;
		} else {
			args[0] = getForm();
		}
		var fieldList;
		openMultiDialog(args, "/page/_Dialog.jsp", fromIoName, toIoName, actName, fieldNames, dlgFeatures, buttonName);
	}
}
function openMultiDialog(args, dialogPath, fromIoName, toIoName, actName, fieldNames, dlgFeatures, buttonName) {
	// ダイアログ呼出
	var requestURL = getContextPath() + dialogPath +
		"?_dialog_io="+toIoName+
		"&_dialog_opener_io="+fromIoName+
		"&_dialog_opener_action="+actName;

//	ret = showDialogPreventInput(requestURL, args, dlgFeatures);
	showDialog(requestURL, args, dlgFeatures);

	_dialogCallBack = function(ret) {
		recoverFocus(buttonName);

		// ダイアログ戻値設定
		isRet = (ret != undefined) && (ret.length > 0);
		if( !isRet ) return ;

		if(fieldNames != "") {
			var fieldList = fieldNames.split(",");
			for (var k = 0; k < fieldList.length; k++){
				if( ret[k] == undefined ) break;
				if( disp.getElement(fieldList[k]) == undefined ) continue;
				disp.set(fieldList[k],ret[k]);
			}
			// 初期値/加工式 再計算
			disp.refresh();
		}
	}
}

/**
 * 複数選択ダイアログ戻値
 * @fieldNames NextIoParamフィールドID（カンマ区切り複数）
 */
function getReturnValueMulti( fieldNames ,fieldName ){
	if(!getResultPreMSG(fieldName)) return;
    var retObj = new Array();
	var fieldList = fieldNames.split(",");

	if(fieldNames != ''){
		for ( var i = 0; i < fieldList.length; i++){
			if( disp.getElement(fieldList[i]) == undefined ){
				retObj[i] = "";
			}
			else{
				retObj[i] = disp.get(fieldList[i]);
			}
		}
	}
	return retObj;
}

/**
 * returnValueをformから組み立てる
 */
function getReturnValue(param){
	if (param == undefined) {
		param = "";
	} else {
		param = preProcessButtonParam(param);
	}
	var pList = param.split(',');
	var retObj = new Array();
	{
		// 選択値
		var value = "";
//		var elem getForm()0][pList[0]];
		var elem = document.forms[0][pList[0]];
		if ("checkbox" == elem.type) {
			if (elem.checked) {
				value = "true";
			} else {
				value = "false";
			}
		} else {
			value = elem.value;
		}
		retObj["value"] = value;
	}
	// 選択表示値
	{
		var retDispStr = "";
		var dm = "";
		for (var i = 1; i < pList.length; i++){
//			var elem getForm()0][pList[i]];
			var elem = document.forms[0][pList[i]];
			var value = "";
			if ("checkbox" == elem.type) {
				if (elem.checked) {
					value = "true";
				} else {
					value = "false";
				}
			} else {
				value = elem.value;
			}
			retDispStr += dm + value;
			dm = " ";
		}
		retObj["disp"] = retDispStr;
	}
	return retObj;
}
/**
 * ダイアログ用リクエスト送信
 * @param params
 */
function dialogAction(params, buttonName) {
	try {
		var url = disp.form.action;
		var fixParams =
			('method=event_getDialogParameter');
		var callback = function(jsonData,err) {
			do_dialog(jsonData,err,buttonName);
		};
		sendRequest("POST",url,false,callback,fixParams+params,disp._encoding);
	} catch (e) {
		showStatusBar(e.message,"ERROR");
	}
	return false;
}
function do_dialog(jsonData,err,buttonName) {
	if(err!=null){
		showStatusBar(err.message,"ERROR");
		return ;
	}
	showStatusBar("");
	eval(jsonData);
	var args;
	var dialogPath;
	var fromIoName = _dialogParam.fromIoName;
	var toIoName = _dialogParam.toIoName;
	var actName = _dialogParam.actionName;
	var fieldNames = _dialogParam.fieldNames;
	var dlgFeatures = _dialogParam.dlgFeatures;
	if(!_dialogParam._na) {
		dialogPath = "/page/_DialogQuick.jsp";
		args = new Object();
		args.params = _dialogParam.paramList;
//		args._wfinfo = document.forms[0]._wfinfo;
		args._wfinfo = getForm()._wfinfo.value;
	} else {
		dialogPath = "/page/_Dialog.jsp";
		args = new Array();
//		args[0] = document.forms[0];
		args[0] = getForm();
	}
	openMultiDialog(args, dialogPath, fromIoName, toIoName, actName, fieldNames, dlgFeatures, buttonName);
}

function updateDOM(inputField) {
	if (inputField.type == "select-one" || inputField.type == "select-multiple") {
		for (var i = 0; i < inputField.options.length; i++) {
			if (inputField.options[i].selected) {
				inputField.options[i].setAttribute("selected", "selected");
			} else {
				inputField.options[i].removeAttribute("selected");
			}
		}
	} else if (inputField.type == "checkbox" || inputField.type == "radio") {
		if (inputField.checked) {
			inputField.setAttribute("checked", "checked");
		} else {
			inputField.removeAttribute("checked");
		}
	} else {
		inputField.setAttribute("value", inputField.value);
	}
}

function updateAllDOMFields(form) {
	var inputFields = form.getElementsByTagName("input");
	var selectFields = form.getElementsByTagName("select");
	var textFields = form.getElementsByTagName("textarea");

	var fieldsSets = new Array(inputFields, selectFields, textFields);
	for (var i = 0; i < fieldsSets.length; i++) {
		var fieldsSet = fieldsSets[i];
		for (var j = 0; j < fieldsSet.length; j++) {
			updateDOM(fieldsSets[i][j]);
		}
	}
}

/**
 * ボタンパラメータ値取得
 */
function preProcessButtonParam(param) {
	var p = param.split(',');

	if (p == null)
		return null;
	var idxList = new Array();
	var paramList = new Array();
	for (var i = 0; i < p.length; i++) {
		var elem = Trim(p[i]);
		if (elem.length > 0) {
			// プロパティ名と添え字リストの分離
			if (elem.match(/^\[/)) {
				// '[',']'を'\[','\]'に置換
				//elem = elem.replace(/\[/,'\\[');
				//elem = elem.replace(/\]/,'\\]');
				idxList.push(elem);
			} else {
				paramList.push(elem);
			}
		}
	}
	var result = "";
	var dm = "";
	for (i in paramList) {
		var prop = paramList[i];
		for (j in idxList) {
			var index = idxList[j];
			// 添え字組み立て
			prop = prop.replace(/\[\]/, index);
		}
		result += dm + prop;
		dm = ",";
	}
	return result;
}
/**
 * Trim
 */
function Trim(str){
	str = str.replace(/^ +/,"");
	str = str.replace(/ +$/,"");
	return str;
}
function TrimWhiteSpace(str){
	str = str.replace(/^[ \f\n\r\t\v]+/,"");
	str = str.replace(/[ \f\n\r\t\v]+$/,"");
	return str;
}

/**
 * objを表示領域中央へ移動
 */
function getClientWidth() {
	if (window.innerWidth) {
		return window.innerWidth;
	}
	return document.body.clientWidth;
}
function getClientHeight() {
	if (window.innerHeight) {
		return window.innerHeight;
	}
	return document.body.clientHeight;
}

function getTopWindowClientWidth() {
	if (window.top.innerWidth) {
		return window.top.innerWidth;
	}
	return window.top.document.body.clientWidth;
}
function getTopWindowClientHeight() {
	if (window.top.innerHeight) {
		return window.top.innerHeight;
	}
	return window.top.document.body.clientHeight;
}

function disp_mes(obj){
	var mes = getItemById(obj);
	if (!mes) {
		return;
	}
	var clientHeight = getTopWindowClientHeight();
	var clientWidth = getTopWindowClientWidth();
	mes.style.display = 'block';
	mes.style.position = 'absolute';
	var top = (clientHeight - mes.offsetHeight) / 2 + getTopWindowScrollTop();
	mes.style.top = top + "px";
	var left = (clientWidth - mes.offsetWidth) / 2 + getTopWindowScrollLeft();
	mes.style.left = left + "px";
	if (isMSIE() || isMSEdge()) { // IE
		var base = getItemById("_basemsg");
		base.style.display = 'block';
		base.style.position = 'absolute';
		base.style.posWidth = mes.offsetWidth;
		base.style.posHeight = mes.offsetHeight;
		base.style.top = (clientHeight - base.offsetHeight) / 2 + getTopWindowScrollTop();
		base.style.left = (clientWidth - base.offsetWidth) / 2 + getTopWindowScrollLeft();
		try {
			// HTML5
			mes.style.top = base.style.top + "px";
			mes.style.left = base.style.left + "px";
		} catch(e) {
			// HTML4
			mes.style.top = base.style.top;
			mes.style.left = base.style.left;
		}
	}
}

function getTopWindowScrollTop(){
	var docElem =  window.top.document.documentElement;
	var docBody =  window.top.document.body;
	return docElem.scrollTop || docBody.scrollTop;
}

function getTopWindowScrollLeft(){
	var docElem =  window.top.document.documentElement;
	var docBody =  window.top.document.body;
	return docElem.scrollLeft || docBody.scrollLeft;
}

/**
 * objを非表示
 */
function clear_mes(obj){
	var mes = getItemById(obj);
	mes.style.display = 'none';
	var base = getItemById("_basemsg");
	base.style.display = 'none';
	window.status=" "; // ""では消えない
}

/*
 * 親がいるときに立てる
 */
var _hasParent = false;
function setHasParent(hasP){
	_hasParent = hasP;
}
function hasParent(){
	return _hasParent;
}

function dispatchAddEventListener(type,listener,options) {
	if (window.addEventListener) {
		window.addEventListener(type, resize_ScreenLock, options);
	}else if(window.attachEvent) { //IE5-
		window.attachEvent('on' + type, listener);
	}
}

function dispatchRemoveEventListener(type,listener,options) {
	if (window.removeEventListener) {
		window.removeEventListener(type, resize_ScreenLock, options);
	}else if(window.detachEvent) { // IE5-
		window.detachEvent('on' + type, listener);
	}
}

function disp_ScreenLock() {
	dispatchAddEventListener("scroll", resize_ScreenLock, false);
	var layer = getItemById("_slock");
	if(layer != undefined) {
		// スクリーンロックをコンテンツ（margin、border、paddingを含めない）のサイズにする。
		layer.style.display = "block";
		if (isHTML5()) {
			var scrollingElement = getScrollingElement();
			layer.style.width = $(scrollingElement).width() + "px";
			layer.style.height = $(scrollingElement).height() + "px";
			layer.style.top = "0px";
			layer.style.left = "0px";
		} else {
			layer.style.width = document.body.clientWidth;
			layer.style.height = document.body.clientHeight;
			layer.style.top = document.body.scrollTop + "px";
			layer.style.left = document.body.scrollLeft + "px";
		}
	}
}

function getScrollingElement() {
	if ('scrollingElement' in document) {
		return document.scrollingElement;
	}
	if (navigator.userAgent.indexOf('WebKit') != -1) {
		return document.body;
	}
	return document.documentElement;
}

function resize_ScreenLock() {
	if(isScreenLock()) {
		disp_ScreenLock();
	}
	return true;
}

function clear_ScreenLock() {
	var layer = getItemById("_slock");
	if(layer != undefined) {
		layer.style.display = "none";
	}
	return true;
}

/**
 * 画面のスクロール位置を取得
 */
function getDispPos() {
	var pos = new Array();
	if(getForm()._on_dialog == undefined) {
		//ダイアログ以外
		pos["x"] = document.body.scrollLeft || document.documentElement.scrollLeft || 0;
		pos["y"] = document.body.scrollTop || document.documentElement.scrollTop || 0;
	} else {
		//ダイアログ
		pos["x"] = getParentWindowScrollLeft();
		pos["y"] = getParentWindowScrollTop();
	}
	return pos;
}

function getParentWindowScrollLeft(){
	var docElem = parent.document.documentElement;
	var docBody = parent.document.body;
	return docElem.scrollLeft || docBody.scrollLeft;
}

function getParentWindowScrollTop(){
	var docElem = parent.document.documentElement;
	var docBody = parent.document.body;
	return docElem.scrollTop || docBody.scrollTop;
}

/**
 * 画面のスクロール位置をセット
 */
function setDispPos(x, y) {
//	if(document.forms[0]._on_dialog == undefined) {
	if(getForm()._on_dialog == undefined) {
		//ダイアログ以外
		document.body.scrollLeft = x;
		document.body.scrollTop = y;
		document.documentElement.scrollLeft = x;
		document.documentElement.scrollTop = y;
	} else {
		//ダイアログ
		parent.scrollTo(x,y);
	}
}

/**
 * Calendarイベントハンドラ
 * @fieldName フィールド名
 * @dtType フィールドデータタイプ名
 */
function onCalBtnClick(fieldName, dtType, label, buttonName, func){
	if (isScreenLock()) return; // 送信中であれば表示しない。
//	var paramValue = document.forms[0][fieldName].value;
	var paramValue = getForm()[fieldName].value;
	if(paramValue.match(/\?|\=|&/)) {
		 paramValue = "";
	}
	var args = new Array();
	args[0] = dtType;
	args[1] = paramValue;
	args[2] = label;
	args[3] = getContextPath() + "/page/_calendar.jsp";

	var dialogHeight;
//	var ua = navigator.userAgent;
//	if (ua && ua.toLowerCase().indexOf("msie 6.") != -1) { // IE6
	if (isMSIE()) {
		dialogHeight = "490px";
	} else {
		dialogHeight = "420px";
	}
	var options = "resizable:yes; status:no; scroll:no; dialogHeight:" + dialogHeight + "; dialogWidth:420px";
//    ret = showDialogPreventInput(getContextPath() + "/page/_sysCalendar.jsp?do="+getContextPath() + "/page/_calendar.jsp",args, options);
	showDialog(getContextPath() + "/page/_sysCalendar.jsp",args, options);
	_dialogCallBack = function(ret) {
		recoverFocus(buttonName);
		func(ret);
	}
//    return ret;
}

/**
 * ページ内でIDが一意である場合に、指定されたIDの要素を返します。
 * @param id ID
 * @returns 要素
 */
function getItemById(id) {
//	return document.getElementById(id);
	var elem = document.getElementById(id);
	if (!elem) {
		 node = document.getElementsByName(id);
		if(node != null && node.length != undefined) {
			elem = node[0];
		}
	}
	return elem;
}

/**
 * 指定された名前のフォーム内の要素を返します。
 * @param name 名前
 * @returns 要素
 */
function getItemByName(name) {
//	return document.forms[0][name];
	return getForm()[name];
}

var SameAsNodeList = function(elements) {
	this.elements = elements;
	this.length = elements.length;
}

SameAsNodeList.prototype = {
	item: function(index) {
		return this.elements[index];
	}
}

/**
 * getItemsByIdの結果がリスト形式か否かを判定します。
 * @param obj getItemsByIdの結果
 * @return リスト形式のときtrue, 要素のときfalse
 */
function isListItems(obj) {
	return (obj.length != undefined && obj.selectedIndex == undefined);
}

/**
 * ページ内でIDが一意でない場合に、指定されたIDの要素を返します。
 * IDが存在しない場合はundefinedを返します。
 * インデックスが指定された場合は、そのインデックスの要素を返します。
 * インデックスが指定されない場合は、IDが一つの場合はその要素、複数の場合はNodeListを返します。
 * @param id ID
 * @param index インデックス
 * @returns 要素
 */
function getItemsById(id, index) {
	if (document.all) {
		if (index == undefined) {
			return document.all.item(id);
		} else {
			var ret = document.all.item(id, index);
			//IE10でnullになるので取り直す
			if(!ret) {
				ret = getItemsByIdAll(id, index);
			}
			return ret;
		}
	} else {
		return getItemsByIdAll(id, index);
	}
}

/**
 * ページ内でIDが一意でない場合に、指定されたIDの要素を返します。
 * IDが存在しない場合はundefinedを返します。
 * インデックスが指定された場合は、そのインデックスの要素を返します。
 * インデックスが指定されない場合は、IDが一つの場合はその要素、複数の場合はNodeListを返します。
 * @param id ID
 * @param index インデックス
 * @returns 要素
 */
function getItemsByIdAll(id, index) {
	var elements = document.getElementsByTagName('*');
	var matched = [];
	for (var i = 0; i < elements.length; i++) {
		if (endsWith(elements[i].id, id)) {
			matched.push(elements[i]);
		}
	}
	if (matched.length == 0) {
		return undefined;
	}
	if (index == undefined) {
		if (matched.length == 1) {
			return matched[0];
		} else {
			return new SameAsNodeList(matched);
		}
	} else {
		return matched[index];
	}
}

/**
 * ページ内で指定されたタグ名の要素を返します。
 * インデックスが指定された場合は、そのインデックスの要素を返します。
 * インデックスが指定されない場合は、NodeListを返します。
 * @param id ID
 * @param index インデックス
 * @returns 要素
 */
function getItemsByTag(name, index) {
	if (document.getElementsByTagName) {
		var elements = document.getElementsByTagName(name);
		if (index == undefined) {
			return elements;
		} else {
			return elements.item(index);
		}
	} else {
		if (index == undefined) {
			return document.all.tags(name);
		} else {
			return document.all.tags(name)(index);
		}
	}
}


/**
 * 画面上部メッセージ表示・拡張/折畳処理
 * @isExpand 表示を広げるかどうか true-広げる false-折畳む
 */
function expandMessage(isExpand){
	// no message
	var mesList = getItemsById("messageLine");
	if( mesList == undefined ) return;

	// not singleline
	var mesExpand = getItemsById("messageExpand");
	if( mesExpand == undefined ) return;

	// one message
	var len = mesList.length;
	if( !isListItems(mesList)){
		getItemsById("messageLine",0).style.display= "" ;
		getItemsById("messageExpand",0).style.display= "none";
		getItemsById("messageCollapse",0).style.display= "none";
		return;
	}

	// multi message
	for (i = 0; i < len ; i++) {
		obj = mesList.item(i).style.display= isExpand ? "" : "none";
	}
	getItemsById("messageLine",0).style.display= "" ;
	getItemsById("messageExpand",0).style.display= isExpand ? "inline" : "none";
	getItemsById("messageCollapse",0).style.display= isExpand ? "none" : "inline";
}

/**
 * 拡張「外部リンク」起動処理
 * @disp 引数情報が格納されているオブジェクト
 * @url リンク先URL
 * @target リンク表示先ターゲット
 */
function doLink(disp, url, target) {
	var args = disp.getArgs();

	var args_p = [];
	for(i=0; i<args.length;i++) {
		args_p[i] = normalizeCRLF(args[i]);
	}
	url = replaceHolder(url, args_p);

	try {
		var w = window.open(url, target);
		if (w != null) {
				w.focus();
		}
	} catch (e) {
		// ignore
	}
	return false;
}

function replaceHolder(pattern, args) {
	for (var i = 0; i < args.length; i++) {
		regex = new RegExp("\\{" + (i+1) + "\\}","g");
		pattern = pattern.replace(regex,disp._encodeParamExternal(args[i]));
	}
	return pattern;
}

function replaceHolderNoEscape(pattern, args) {
	for (var i = 0; i < args.length; i++) {
		regex = new RegExp("\\{" + (i+1) + "\\}","g");
		pattern = pattern.replace(regex,args[i]);
	}
	return pattern;
}

function do_download(actionName, formName, parentName, targetName, buttonIndex, downloadable, fieldName) {
	if(!getResultPreMSG(fieldName)) return;

	if( downloadable == "true") {
		var id = create_FieldName(parentName, targetName, buttonIndex);
		var form = document.forms[ formName ];
		form.action = actionName + "Download.do";
		var item = getForm().elements[ id ];
		if(item != undefined) {
			form.fileId.value = item.value;
			var requestParam = "fileId=" + item.value;
			var hostUrl= actionName + "Download.do";
			var param = hostUrl + "?" + requestParam;

			var w = window.screenX || window.screenLeft;
		    var h = window.screenY || window.screenTop;

			showDialog(getContextPath() + '/page/downloadProcess.jsp?actionDo=' + hostUrl +'&fileId=' + item.value + '&_on_dialog=true','sub', 'height=320, width=820, resizable=yes, status=yes, scrollbars=yes, left='+w+', top='+h);
		}
	}
}

function file_download(fileName, fileBlob) {
	//ダイアログを閉じる。
	close_Dialog();
	//ファイルをダウンロードする。
    if (navigator.appVersion.toString().indexOf('.NET') > 0) {
        //IE 10+
    	var fileBuffer = string_to_buffer(fileBlob);
    	var blob = new Blob([fileBuffer], {type:"application/octet-binary"});
    	window.navigator.msSaveOrOpenBlob(blob, fileName);
    } else {
    	//aタグの生成
        var a = document.createElement("a");
        var userAgent = window.navigator.userAgent.toLowerCase();
        var blobUrl;
        if(userAgent.indexOf('edge') != -1) {
        	var fileBuffer = string_to_buffer(fileBlob);
        	var blob = new Blob([fileBuffer], {type:"application/octet-binary"});
        	blobUrl = window.URL.createObjectURL(blob);
        } else {
	        //レスポンスからBlobオブジェクト＆URLの生成
	        blobUrl = window.URL.createObjectURL(new Blob([fileBlob]));
        }
        //上で生成したaタグをアペンド
        document.body.appendChild(a);
        a.style = "display: none";
        //BlobオブジェクトURLをセット
        a.href = blobUrl;
        //ダウンロードさせるファイル名の生成
        a.download = fileName;
        //クリックイベント発火
        a.click();
        window.URL.revokeObjectURL(blobUrl);
        $(a).remove();
    }
}

function pre_download() {
	return pre_submit("a_onload","","送信中...", 0);
}

function string_to_buffer(src) {
	return (new Uint8Array([].map.call(src, function(c){
		return c.charCodeAt(0)
	}))).buffer;
}

function create_FieldName(parentName, targetName, buttonIndex) {
	if(parentName == undefined || parentName == "") {
		return targetName;
	}
	return parentName + "[" + buttonIndex + "]." + targetName;
}

/**
 * フィールドにエラー表示設定。
 * 引数の内容はjp.co.canon_soft.wp.runtime.util.FieldInfoの各メンバ。
 *
 * @isField フィールドか
 * @isGroup グループか
 * @fieldName フィールド名
 * @groupIndex 一覧インデックス
 * @srcField フィールド名の原型
 */
function setErrField( isField, isGroup, fieldName, groupName, groupIndex, srcField ){
	var errorClass = 'item__ERROR';
	try {
		if(isField){
			if(isGroup){
				disp.setCur_index(groupIndex);
			}
			disp.setClassByName(fieldName, errorClass);
		}else{
			if(isGroup){
				setClass4ItemByTagID(fieldName, groupName, groupIndex, errorClass );
			}else{
				setClass4Item(fieldName, errorClass);
			}
		}
	} catch(e) {
		// ignore
	}
}

/**
 * フィールドにカーソル表示設定。
 * 引数の内容はjp.co.canon_soft.wp.runtime.util.FieldInfoの各メンバ。
 *
 * @isField フィールドか
 * @isGroup グループか
 * @fieldName フィールド名
 * @groupIndex 一覧インデックス
 * @srcField フィールド名の原型
 * @isTryNextFocus true:次フィールドへフォーカスを移動する
 */

function setCurField(isField, isGroup, fieldName, groupIndex, srcField, isScroll, isTryNextFocus) {
	if (isGroup) {
		disp.setCur_index(groupIndex);
	}
	var focusControlId;
	var focusControlName = srcField;
	if (focusControlName == "") {
		focusControlName = fieldName;
	}
	try {
		var retVal = false;
		if (isField) {
			var info = eval("disp.get_metaInfo" + fieldName + "()");
			focusControlId = info.ioItemCode;
			var focusControl = disp.getElement(focusControlId);
			if (focusControl != undefined) {
				if (focusControl.type == "hidden") {
					if (info.itemType != "O") {
						var focusControlName = "";
						if (isGroup) {
							focusControlName = focusControl.name.substr(0,focusControl.name.indexOf(".") + 1);
						}
						focusControlName = "_" + focusControlName  + info.ioItemPropName + "_Choicelist_list";
						focusControl = document.getElementsByName(focusControlName)[0];
					}
				} else if (focusControl.type != undefined && focusControl.type.toLowerCase().indexOf("select") != -1) {
					var focusControlName = info.ioItemPropName + "DlgBtn";
					if (isGroup) {
						focusControlName += "[0]";
					}
					var dlgBtn = document.getElementsByName(focusControlName)[0];
					if (dlgBtn != undefined) {
						focusControl = document.getElementsByName(focusControlName)[0];
					}
				}
				if (focusControl.type == undefined || focusControl.type.toLowerCase().indexOf("select") == -1) {
					if (focusControl.length != undefined && focusControl.length != null && focusControl.length > 1) {
						focusControl = focusControl[0];
					}
				}
			}
			retVal = setFocus4Item(focusControl, isScroll);
		} else {
			// focusControl = document.forms[0].elements[srcField];
			var focusControl = getForm().elements[srcField];
			if (focusControl != undefined) {
				if (focusControl.length != undefined && focusControl.length != null && focusControl.length > 1) {
					if (focusControl[0].type == "checkbox") {
						focusControl = focusControl[0];
					}
				}
				retVal = setFocus4Item(focusControl, isScroll);
			}
			var pos = 3;
			if (isGroup) {
				pos += focusControl.id.indexOf(".") + 1;
			}
			focusControlId = focusControl.id.substr(pos);
		}
		if (!retVal && isTryNextFocus && !isIPhone() && !(isIPad() && isMobile())) {
			moveNextFocus(focusControlId, focusControlName, 3);
		}

		return retVal;
	} catch (e) {
		return false;
	}
}

/**
 * 要素にフォーカスがあればフォーカスをあてなおします。
 * データ入れ替え時フォーカスが見えなくなるIE動作のワークアラウンド処理です。
 *
 * @elem 対象フォーム要素
 */
function refocus( elem ){
	setTimeout(function() {
		try {
			if(document.activeElement){
				if(document.activeElement.name == elem.name){
					setFocus4Item(elem,false);
				}
			}
		} catch (e) {
			// ignore
		}
	}, 0);
}

/**
 * ラジオボタン/複数選択チェックボックスのフォーカスを修復します。
 *
 * ラジオボタン/複数選択チェックボックスの選択リスト要素がフォーカスを持っていた場合、
 * 選択リスト要素が入れ替わった場合フォーカスを失うため、その修復処理を行います。
 */
function refocusRadio(){
	try {
		if(disp._focusRecovery){
			window.setTimeout(
				function(){
					try{
						disp._focusRecovery();
						if( !document.activeElement.name ) {
							// focus fail, retry.
							refocusRadio();
						}else{
							disp._focusRecovery = null;
						}
					} catch (e) {
						// ignore
					}
				}
			, 0 );
		}
	} catch (e) {
		// ignore
	}
}

/**
 * プルダウン/リストボックス/複数選択リストボックスのフォーカスを修復します。
 *
 * プルダウン/リストボックス/複数選択リストボックスがフォーカスを持っていた場合、
 * 本来選択リスト要素が入れ替わった場合でもフォーカスは失いませんが、
 * IE動作によりフォーカスを失う場合があるため、再度フォーカス処理を行います。
 * またボタン要素でも同様のことが発生するため、この対象とします。
 */
function refocusPulldown(){
	try {
		if(document.activeElement && document.activeElement.name){
			if( existField(document.activeElement.name,disp.getPulldownField())
				|| document.activeElement.type == "button" ) {
				var elem = document.activeElement;
				window.setTimeout(
					function(){
						try{
							setFocus4Item(elem,false);
						} catch (e) {
							// ignore
						}
					}
				, 0 );
			}
		}
	} catch (e) {
		// ignore
	}
}

/**
 * フォーカスをアイテムに設定。
 *
 * @param focusControl フォーム要素
 * @param isScroll スクロール有無
 */
function setFocus4Item( focusControl, isScroll ) {
	try {
		var scrollMode = true;
		if(isScroll != undefined) scrollMode = isScroll;
		if (focusControl.type != "hidden") {
			clearSelection();
			if(!canFocus(focusControl)){
				return false;
			}
			if(scrollMode){
				focusControl.focus();
				focusControl.scrollIntoView();
				if (focusControl.type == "text" || focusControl.type == "file" || focusControl.type == "password") {
					selectTextRange(focusControl, true);
				} else if(focusControl.tagName == "TEXTAREA"){
					selectTextRange(focusControl, false);
				}
			}else{
				var keyCode;
				try {
				    keyCode= getKeyCode();
				} catch (e) {
				}
				if (keyCode && 111 < keyCode && keyCode < 124) {
					focusControl.focus();
				} else {
					asyncFocus(focusControl, true);
				}
			}
			return true;
		} else {
			return false;
		}
	} catch (e) {
		return false;
	}
}

/**
 * コントロールがフォーカス関数実行可能か検証する。
 * @param focusControl フォーカス対象コントロール
 */
function canFocus( focusControl ) {
	if(focusControl.focus == undefined){
		return false;
	}
	if(focusControl.disabled == true){
		return false;
	}

	// 親が非表示だとフォーカスに失敗する
	var p = focusControl;
	var cs;
	while(p!=null && p!=window.document){
		if(window.getComputedStyle){
			cs = getComputedStyle(p,'');
		}else if(p.currentStyle){
			cs = p.currentStyle;
		}else{
			// not support
		}
		if(cs){
			if(cs.display=="none" || cs.visibility=="hidden"){
				return false;
			}
		}
		p = p.parentNode;
	}

	return true;
}

/**
 * テキスト項目にフォーカスを設定する。
 * @param item テキスト項目
 * @param selectAll 文字列を選択状態にするときtrue, フォーカスを設定するが選択状態にしないときfalse
 */
function selectTextRange(item, selectAll) {
	try {
		if (item.setSelectionRange) {
		    var pos = (selectAll ? item.value.length : 0);
		    item.setSelectionRange(0, pos);
		} else {
		    var rng = item.createTextRange();
		    if (!selectAll) {
		    	rng.collapse(true);
		    }
		    rng.select();
		}
	} catch (e) { }
}

/**
 * 選択状態を解除します。
 */
function clearSelection() {
	if (document.selection) {
		try {
			document.selection.empty();
		} catch(e) {}
	} else if (window.getSelection) {
		window.getSelection().removeAllRanges();
	}
}

/**
 * スタイルシート・クラスをアイテムに設定。
 *
 * @param tagID フォーム要素タグID
 * @param _classname クラス
 */
function setClass4Item ( tagID, _classname) {
	var styleObj = getItemById(tagID);
	if( styleObj != undefined ){
		var oldClassName = styleObj.className;
		styleObj.className = oldClassName + " " + _classname;
	}
}

/**
 * スタイルシート・クラスをアイテムに設定。（グループ用）
 * ファイル項目、MATRIX画面にも対応。
 *
 * @param tagID HTMLタグのID
 * @param groupName グループ（PROP）名
 * @param index グループレコード番号（ページ内ではなくグループ全件内での番号）
 * @param className セットするCSSクラス名
 */
function setClass4ItemByTagID( tagID, groupName, index, _classname ) {
	var i = 0;
	if (index == -1) {/* all */
		var elements = getItemsByTag("DIV");
		for(i = 0; i < elements.length; i++) {
			var targetid = elements.item(i).id;
			if(targetid != undefined && targetid.match("^"+tagID)) {
				var targetElement = elements.item(i);
				var oldClassName = targetElement.className ;
				targetElement.className = oldClassName + " " + _classname;
			}
		}
		return ;
	}
	var gTagID = tagID+"."+groupName+"["+index+"]";
	var mesList = getItemsById(gTagID);
	if( mesList == undefined ) return;

	var len = mesList.length;
	if( !isListItems(mesList)){
		var oldClassName = mesList.className ;
		mesList.className = oldClassName + " " + _classname;
	}else{
		for (i = 0; i < len; i++) {
			var oldClassName = mesList.item(i).className;
			mesList.item(i).className = oldClassName + " " + _classname;
		}
	}
}

/**
 * 印刷アクションの印刷前実行アクションを起動
 *
 * @param ioItemCode 印刷アクション・入出力項目コード
 * @param preaction 印刷アクション・印刷前実行アクションコード
 * @param index 印刷アクション・行番号
 *
 * @return 印刷前実行アクションを行ったかどうか
 */
function doPrintPreaction(ioItemCode, preaction, index){
	var preactionStatusElem = document.getElementById("_printPreactionStatus");

	// 印刷前実行アクションが定義されている場合、まず、印刷前実行アクションを起動
	if(preaction && preaction != "" && preactionStatusElem.value != "done"){

		if(!index){
			disp.setCur_index(index);
		}
		var preactionElem = disp.getElement(preaction);
		if(!preactionElem){ // 定義されている印刷前実行アクションが見つからない
			return false;
		}

		// 後に行う印刷アクションの項目コード/行番号をサーバ<=>クライアントで引き回す
		var printActionHavingPreactionElem = document.getElementById("_printActionHavingPreaction");
		printActionHavingPreactionElem.value = ioItemCode;
		var printActionHavingPreactionIndexElem = document.getElementById("_printActionHavingPreactionIndex");
		printActionHavingPreactionIndexElem.value = index;

		// _blankの場合、印刷前実行アクション後Windowを見失うため、便宜UUIDを付与する
		var printForm = document.getElementsByName(ioItemCode+"_form")[0];
		if(isPrintformTargetBlank(printForm.target)){
			printForm.target = generateUUID();
		}

		// _self以外の場合、ターゲット名をサーバ<=>クライアントで引き回す
		if(!isPrintformTargetSelf(printForm.target)){
			var printActionHavingPreactionWindownameElem = document.getElementById("_printActionHavingPreactionWindowname");
			printActionHavingPreactionWindownameElem.value = printForm.target;
		}

		// 印刷前実行アクションを起動
		preactionElem.click();// サブミットが行われ、印刷処理は、印刷前実行アクション処理後、自画面のonloadで行われる。

		// _self以外の場合、ポップアップブロック対策のため、あらかじめ指定名でWindowを表示しておく
		if(!isPrintformTargetSelf(printForm.target)){
			window.open("page/wait.jsp", printForm.target);
		}
		return true;
	}
	// 印刷前実行アクションが完了済（done）か、印刷前実行アクションの設定がない
	return false;
}

function generateUUID() {
	// UUIDは本来ハイフン区切りだが、formのターゲット名に使用した場合、HTML4+IEでエラーになる
	// よってアンダーバー区切りとする
	var chars = "xxxxxxxx_xxxx_4xxx_yxxx_xxxxxxxxxxxx".split("");
	for (var i = 0, len = chars.length; i < len; i++) {
		switch (chars[i]) {
			case "x":
				chars[i] = Math.floor(Math.random() * 16).toString(16);
				break;
			case "y":
				chars[i] = (Math.floor(Math.random() * 4) + 8).toString(16);
				break;
		}
	}
	return chars.join("");
}

function isPrintformTargetBlank(target) {
	// 「targetが_blank」ないし「_blankのため前回付与されたUUID」
	return target == "_blank" || target.match(/^[0-9a-f]{8}_[0-9a-f]{4}_4[0-9a-f]{3}_[89ab][0-9a-f]{3}_[0-9a-f]{12}$/);
}

function isPrintformTargetSelf(target) {
	return target == "_self";
}

var closePreopenWindowWhenPrintActionError; // 印刷アクション失敗時Windowクローズ用関数
/**
 * 印刷前実行アクション後の印刷アクションを起動
 *
 * @param printActionHavingPreaction 印刷アクション・入出力項目コード
 * @param printPreactionError 印刷前実行アクションが成功していれば空文字、失敗していたら「__ERROR__」
 * @param printActionHavingPreactionWindowname 印刷アクション・ターゲットWindow名
 * @param index 印刷アクション・行番号（無い場合は-1）
 */
function printIfPreactionFinish(printActionHavingPreaction, printPreactionError, printActionHavingPreactionWindowname, index) {
	setTimeout(function () {
		var printForm = document.getElementsByName(printActionHavingPreaction + "_form")[0];
		// フォームがないのはエラーページ
		if(!printForm){
			if (printActionHavingPreactionWindowname != "") {
				closePreopenWindow(printActionHavingPreactionWindowname);
				return;
			}
		}

		// _blankのWindow名（代替UUID）を復元
		if (printActionHavingPreactionWindowname != "") {
			if(isPrintformTargetBlank(printForm.target)){
				printForm.target = printActionHavingPreactionWindowname;
			}
		}

		if (printPreactionError != "") {
			// 印刷前アクションでエラーが発生していたら、事前に起動していたWindowを閉じる(_self以外)
			if(!isPrintformTargetSelf(printForm.target)){
				closePreopenWindow(printForm.target);
			}
		} else {
			// 印刷アクションの起動（ボタンを押す）
			var preactionStatusElem = document.getElementById("_printPreactionStatus");
			preactionStatusElem.value = "done"; // 印刷前アクション実行済フラグ
			if(index > -1){
				disp.setCur_index(index);
			}
			var printActionElem = disp.getElement(printActionHavingPreaction);
			if(printActionElem){
				if(!isPrintformTargetSelf(printForm.target)){
					var target = printForm.target;
					closePreopenWindowWhenPrintActionError = function(){
						closePreopenWindow(target);
						closePreopenWindowWhenPrintActionError = null;
					}
				}
				printActionElem.click();
			}
			preactionStatusElem.value = "";
		}
	}, 100); //onloadの後処理の最後に積む
}
function closePreopenWindow(target){
	var preOpenWindow = window.open("page/wait.jsp", target);
	if(preOpenWindow){
		preOpenWindow.close();
	}
}

/**
 * チェック（非同期）付印刷・起動関数
 *
 * @param ioCode 印刷アクション・入出力コード
 * @param ioItemCode 印刷アクション・入出力項目コード
 * @param ioItemPropName 印刷アクション・入出力項目プロパティ名
 * @param preaction 印刷アクション・事前アクションコード
 * @param index 印刷アクション・行番号
 */
function doAsyncCheckPrint(ioCode, ioItemCode, ioItemPropName, preaction, index) {
	if(doPrintPreaction(ioItemCode, preaction, index)){
		return;
	}
	showStatusBar(_globalMsgObject.checking);
	try {
		var url = disp.form.action;
		var fixParams ='method=event_Check';
		var params = disp.serialize(undefined,"check");
		// XSS対応の為、コールバック関数で使用するパラメータ受け取らないようにしました。
		var extParams = "&_io_code="+ioCode+"&_ioitem_code="+ioItemCode+"&_ioitem_propname="+ioItemPropName;
//		sendRequest("POST",url,false,doCheckedPrint,fixParams+params+extParams,disp._encoding);
		var doCheckedPrintFunc = "doCheckedPrint(data,err,'" + ioItemCode + "','" +ioItemPropName + "')";
		sendRequest("POST",url,false,doCheckedPrintFunc,fixParams+params+extParams,disp._encoding);
	} catch (e) {
		showStatusBar(e.message,"ERROR");
	}
	return false;
}
/**
 * チェック（非同期）付印刷・コールバック関数
 * チェックがOKであれば実処理を呼び出します。
 *
 * @jsonData チェック結果
 * @err （非同期通信の）エラー情報
 */
//function doCheckedPrint(jsonData,err){
function doCheckedPrint(jsonData, err, code, propName){
	if(err!=null){
		if(closePreopenWindowWhenPrintActionError){
			closePreopenWindowWhenPrintActionError();
		}
		showStatusBar(err.message,"ERROR");
		return ;
	}
	showStatusBar("");

	// ( in 'var _dispData' and 'var checkData' and 'var printData')
	eval(jsonData);

	if(disp._isAsync) disp.setData(_dispData);

	var len = checkData.messages.length;
	if( len > 0 ){ // check error
		var msg = '';
		for(var i=0;i<len;i++){
			msg+=(checkData.messages[i].replace(/\\n/g,'\n')+'\n');
		}
		if(closePreopenWindowWhenPrintActionError){
			closePreopenWindowWhenPrintActionError();
			setTimeout(function(){alert(msg);},100); // chrome対応
		}else{
			alert(msg);
		}
	}

	if(checkData.result=="true"){
		//XSS対応の為、レスポンスのパラメータを受け取らないようにしました。
//		if(printData != undefined){
//			var formName = printData.code + '_form';
//			var propName = printData.prop;
//			var methodName = 'doPrint_'+printData.code;
//			eval(methodName+"("+"'"+formName+"',disp,"+"'"+propName+"'"+")");
//		}else{
//			// assert
//			alert(_globalMsgObject.needInfoPrint);
//		}
		var formName = code + '_form';
		var methodName = 'doPrint_' + code;
		eval(methodName+"("+"'"+formName+"',disp,"+"'"+propName+"'"+")");
	}
}


/**
 * チェック（非同期）付外部リンク・起動関数
 *
 * @linkUrl リンク先URL
 * @linkTarget リンク表示ターゲット
 */
function doAsyncCheckLink(ioCode,ioItemCode,linkUrl,linkTarget) {
	showStatusBar(_globalMsgObject.checking);
	try {
		var url = disp.form.action;
		var fixParams ='method=event_Check';
		var params = disp.serialize(undefined,"check");
		// XSS対応の為、コールバック関数で使用するパラメータをサーバーから受け取らないようにしました。
		var extParams =
			"&_io_code="+ioCode
			+"&_ioitem_code="+ioItemCode
//			+"&_link_url="+disp._encodeParam(linkUrl)
//			+"&_link_tgt="+disp._encodeParam(linkTarget);
			;
//		sendRequest("POST",url,false,doCheckedLink,fixParams+params+extParams,disp._encoding);
		var doCheckedLinkFunc = "doCheckedLink(data,err,'" + ioItemCode + "','" +linkUrl + "','" + linkTarget + "')";
		sendRequest("POST",url,false,doCheckedLinkFunc,fixParams+params+extParams,disp._encoding);
	} catch (e) {
		showStatusBar(e.message,"ERROR");
	}
	return false;
}
/**
 * チェック（非同期）付外部リンク・コールバック関数
 * チェックがOKであれば実処理を呼び出します。
 *
 * @jsonData チェック結果
 * @err （非同期通信の）エラー情報
 */
//function doCheckedLink(jsonData,err){
function doCheckedLink(jsonData, err, code ,url,target) {
	if(err!=null){
		showStatusBar(err.message,"ERROR");
		return ;
	}
	showStatusBar("");

	// ( in 'var _dispData' and 'var checkData' and 'var linkData')
	eval(jsonData);

	if(disp._isAsync) disp.setData(_dispData);

	var len = checkData.messages.length;
	if( len > 0 ){
		var msg = '';
		for(var i=0;i<len;i++){
			msg+=(checkData.messages[i].replace(/\\n/g,'\n')+'\n');
		}
		alert(msg);
	}
	if(checkData.result=="true"){
		//XSS対応の為、レスポンスのパラメータを受け取らないようにしました。
//		if(linkData != undefined){
//			var arg_method = 'setArg_'+linkData.code+'(disp)';
//			eval(arg_method);
//			doLink(disp, linkData.url, linkData.target);
//		}else{
//			// assert
//			alert(_globalMsgObject.needInfoLink);
//		}
		var arg_method = 'setArg_'+code+'(disp)';
		eval(arg_method);
		doLink(disp, url, target);
	}
}
/**
 * HTML文字をエスケープ
 *
 * @str 対象文字列
 */
function escapeHTML(str){
	return str.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/\"/g,"&quot;");
}

function addEventHandler(elementObj, eventName, handler) {
	if(eventName != 'onload') {
		var oldHdl = elementObj[eventName];
		if (typeof elementObj[eventName] != 'function') {
			elementObj[eventName] = handler;
		} else {
			elementObj[eventName] = function(ev) {
				if( ev != undefined ){
					setupEvent(ev);
				}else{
					ev = window.event;
				}
				if (handler(ev)) {
					oldHdl(ev);
				}
			}
		}
	} else {
		addLoadEvent(handler);
	}
}
function addLoadEvent(handler) {
	var oldonload = window.onload;
	if(typeof window.onload != 'function') {
		window.onload = handler;
	} else {
		window.onload = function(ev) {
			if( ev != undefined ){
				setupEvent(ev);
			}else{
				ev = window.event;
			}
			if(handler(ev)) {
				oldonload(ev);
			}
		}
	}
}

function event_MultiChenge(fromName,toName,sep,type) {
	var preVal = disp._previousValues[toName];
	if(preVal==undefined){
//		var toNameElem = document.forms[0][toName];
		var toNameElem = getForm()[toName];
		preVal = getFormPreviousValue(toNameElem);
		disp._previousValues[toName] = preVal;
	}

	if(type != 'checkbox') {
//		var selElm = document.forms[0][fromName];
		var selElm = getForm()[fromName];
		var dm = "";
		var retVal = '';
		for(var i = 0; i < selElm.options.length; i++) {
			if(selElm.options[i].selected == true) {
				retVal = retVal + dm + selElm.options[i].value;
					dm = sep;
			}
		}
//		document.forms[0][toName].value = retVal;
		getForm()[toName].value = retVal;
	} else {
		var dm = "";
		var retVal = '';
		var cElm = document.getElementsByName(fromName);
		if(cElm.length != 'undefined') {
			for(var i = 0; i < cElm.length; i++) {
				if(cElm[i].checked == true) {
					retVal = retVal + dm + cElm[i].value;
					dm = sep;
				}
			}
//			document.forms[0][toName].value = retVal;
			getForm()[toName].value = retVal;
		} else {
			if(cElm.checked == true) {
//				document.forms[0][toName].value = cElm.value;
				getForm()[toName].value = cElm.value;
			}
		}
	}
}

var reg_maxlength = new RegExp("[^0-9]*", "gm");
function cursor_onKeyUp(code) {
	var srcItem = getSrcEventField();
	var localKeyPress = _onkey_press;
	_onkey_press = false;
	var mode = getMoveCusor4Keyup(srcItem, localKeyPress, code);
	var tryFocus = false;
	if(mode > -1) {
		tryFocus = true;
		moveNextFocus(code, srcItem.name, mode);
	}
	_onkey_press = false;
	return tryFocus;
}

function isMoveCusor4Keyup(code) {
	var bool = getMoveCusor4Keyup(getSrcEventField(), _onkey_press, code) == 3;
	return bool;
}

function getMoveCusor4Keyup(srcItem, localKeyPress, code) {
	var mode = -1;
	if((srcItem.tagName == "INPUT" || srcItem.tagName == "SELECT")	&& srcItem.type != "button" && localKeyPress && getKeyCode() == 13) {
		mode = 3;
	} else if(srcItem.tagName == "INPUT" && srcItem.type == "text") {
		var hasSel;
		if (document.selection) {
			var rng = document.selection.createRange();
			rng.moveEnd("textedit");
			hasSel = (rng.text.length > 0);
		} else {
			hasSel = (srcItem.selectionStart < srcItem.value.length);
		}
		if(!hasSel) {
			var info = disp.getMetaInfo(code);
			if(info == undefined) return false;
			var type = info.getCheckType();
			var maxLength = info.getInputLength();
			var checkDataLength = srcItem.value.length;
			if(type == "NUM" || type == "CURRENCY" || type == "DATE" || type == "TIME") {
				var numOnly = srcItem.value.replace(reg_maxlength, "");
				checkDataLength = numOnly.length;
			}
			var isMoveCusor = localKeyPress;
			// Mac Safari でkeypressイベントが発生しない。そのためlocalKeyPressはtrueになることはない
			if(!isMoveCusor && _global_isMACINTOSH && _global_isSAFARI) {
				if(type == "CODE" || type == "NUM" || type == "CURRENCY" || type == "DATE" || type == "TIME") {
					// 全角入力しないフィールドではIME入力中かを考慮せず移動できるようにする
					isMoveCusor = true;
				}
			}
			if((isMoveCusor && checkDataLength == maxLength) || (getKeyCode() == 13 && checkDataLength == maxLength)) {
				mode = 3;
			}
		}
	}
	return mode;
}

function cursor_onKeyDown(code) {
	var srcItem = getSrcEventField();
	var mode = -1;
	if(getKeyCode() == 9 && !isShitKeyPressed()) {
		mode = 3;
	} else if(getKeyCode() == 9 && isShitKeyPressed()) {
		mode = 1;
	}
	var tryFocus = false;
	if(mode > -1) {
		tryFocus = true;
		moveNextFocus(code, srcItem.name, mode);
	}
	return tryFocus;
}

function moveNextFocus(code, name, mode) {
	var _disp = disp;
	var wkCursorInfo = disp._cursorInfo;
	var currentInfo;
	var wkCode = code;
	var defaultRow = 0;
	if(name.match("\\[([0-9]+)\\]")) {
		defaultRow = parseInt(RegExp.$1);
	}
	var wkRow = defaultRow;

	var cursorObj = new CursorObj();
	cursorObj.setRow(wkRow);
	cursorObj.setStartCode(code);
	cursorObj.setStartRow(defaultRow);
	currentInfo = wkCursorInfo[wkCode];
	for(var i = 0; true; i++) {
		//call func
		if(currentInfo==undefined) return;
		cursorObj.setCursorInfo(currentInfo);
		currentInfo[mode](cursorObj, disp);
		if(!cursorObj.isRepeat()) {
			break;
		}
		currentInfo = wkCursorInfo[cursorObj.getNextItemCode()];
	}
	key_tabPressed = true;
}

var _checkField = null;
function checkBlur(fieldName, ioItemCode, checkType, maxLength, maxScale) {
	if(_checkField == null || _checkField == fieldName) {
		var field = getItemByName(fieldName);
		var eventOnblur = field.onblur;
		if(!checkItem(field.value, checkType)) {
			blurCheckOK = false;
			_checkField = fieldName;
		    field.onblur = null;
			alert(replaceMessageParams(_messageList[checkType], new Array((maxLength - maxScale) + "." + maxScale)));
			try {
				asyncFocus(field);
				asyncDeselectDataGrid();
			} catch (e) {
				_checkField = null;
			}
			attachOnBlur(field, eventOnblur);
			return false;
		} else {
			if (checkType == "NUM" || checkType == "CURRENCY") {
				if(!checkNumLength(field.value, maxLength, maxScale)) {
					_checkField = fieldName;
				    field.onblur = null;
					alert(replaceMessageParams(_messageList[checkType], new Array((maxLength - maxScale) + "." + maxScale)));
					try {
						asyncFocus(field);
						asyncDeselectDataGrid();
					} catch (e) {
						_checkField = null;
					}
					attachOnBlur(field, eventOnblur);
					return false;
				} else {
					_checkField = null;
				}
			} else {
				_checkField = null;
			}
		}
	}
	return true;
}

var _asyncActionProcessing = false;
function attachOnBlur(field, eventOnblur) {
	setTimeout(function () {
		if (_asyncActionProcessing) {
			// 非同期通信が戻るのを待つ。
			attachOnBlur(field, eventOnblur);
		} else {
			setTimeout(function () {
				// checkBlurで一時的に無くしたonblurのイベントを付けなおす。
				field.focus();
				field.onblur = eventOnblur;
			}, 100);
		}
	}, 100);
}

function replaceMessageParams(msg, args) {
	return msg.replace(/\{(\d+)\}/g, function(all, group1) {
        return args[Number(group1)];
    });
}

function checkNumLength(fieldValue, maxLength, maxScale, isDataGrid) {
	var fieldValue = changeNum(fieldValue, isDataGrid);
	var maxIntLength = maxLength - maxScale;
	var matched = fieldValue.match(/[^0-9,.]*([0-9,]*)[.]?([0-9]*)[^0-9,.]*/);
	var intValue = matched[1].replace(/,/g, "");
	var scaleValue = matched[2];

	// '0'の場合は桁数にカウントしない。
	if (maxIntLength < 1 && intValue == "0") {
		maxIntLength = 1;
	}
	if (intValue.length > maxIntLength || scaleValue.length > maxScale) {
		return false;
	}
	return true;
}

function changeNum(fieldValue,isDataGrid){
	var str = fieldValue;
	if(!isDataGrid){
		str = fieldValue.split(_groupingSeparator).join('');
	}
    var pos = str.lastIndexOf(_decimalSeparator);
    if (pos > -1) {
        var body = str.substring(0, pos).split(_groupingSeparator).join('');
        return body + '.' + str.substring(pos + _decimalSeparator.length, str.length);
    } else {
        return str;
    }
}

function checkItem(fieldValue, checkType) {
//	var fieldValue = changeNum(fieldValue);
	if(fieldValue == "") return true;
	if(checkType == "TEXT") {
		return true;
	} else if(checkType == "ZENKAKU") {
		return true;
	} else if(checkType == "HANKAKU") {
		return isSingleByte(fieldValue, false);
	} else {
		fieldValue = TrimWhiteSpace(fieldValue);
		if(fieldValue == "") return true;
		if(checkType == "TIME") {
			if(!validateTime(fieldValue)) {
				return false;
			}
		} else if(checkType == "DATE") {
			if(!validateDate(fieldValue)) {
				return false;
			}
		} else {
			if(!isMatchAny(fieldValue, checkType)) {
				return false;
			}
		}
	}
	return true;
}

function validateDate(fieldValue) {
	var elements = "";
	if(_dateFormat_MDY == 1){ //MDY
		elements = getMDYDateElements(fieldValue);
	}else if(_dateFormat_MDY == 2){ //DMY
		elements = getDMYDateElements(fieldValue);
	}else{ //それ以外はYMD
		elements = getYMDDateElements(fieldValue);
	}

	if (elements.length != 3) {
		return false;
	}
	if (_dateValidateStrict) {
		var iYear = Number(elements[0]);
		var iMonth = Number(elements[1]);
		var iDate = Number(elements[2]);
		if (iMonth < 1 || iMonth > 12) {
			return false;
		}
		var lastDate = getLastDayOfMonth(iYear, iMonth);
		if (iDate < 1 || iDate > lastDate) {
			return false;
		}
	}
	return true;
}

/**
 * 指定された年月の月末日を返します。
 */
function getLastDayOfMonth(year, month) {
    var dt = new Date(year, month, 0);
    return dt.getDate();
}

function getDMYDateElements(fieldValue) {
	var matched;
	var sYear;
	var sMonth;
	var sDate;
	matched = fieldValue.match(/(^[0-9]{0,1}[0-9])[/-]([0-9]{1,2})[/-]([0-9][0-9][0-9][0-9]$)/); // DD-MM-YYYY
	if (matched) {
		sYear = matched[3];
		sMonth = matched[2];
		sDate = matched[1];
		if (Number(sYear) < 1000) {
			// '31-12-0005'のような入力は不正とする
			return [];
		}
		return new Array(sYear, sMonth, sDate);
	}
	matched = fieldValue.match(/(^[0-9]{1,2})[/-]([0-9]{0,1}[0-9])[/-]([0-9][0-9]$)/); // DD-MM-YY
	if (matched) {
		sYear = matched[3];
		sMonth = matched[2];
		sDate = matched[1];
		return new Array(sYear, sMonth, sDate);
	}
	matched = fieldValue.match(/^[0-9][0-9]{6}[0-9]$/); // DDMMYYYY
	if (matched) {
		sYear = fieldValue.substring(4, 8);
		sMonth = fieldValue.substring(2, 4);
		sDate = fieldValue.substring(0, 2);
		if (Number(sYear) < 1000) {
			// '31120005'のような入力は不正とする
			return [];
		}
		return new Array(sYear, sMonth, sDate);
	}
	matched = fieldValue.match(/^[0-9][0-9]{4}[0-9]$/); // DDMMYY
	if (matched) {
		sYear = fieldValue.substring(4, 6);
		sMonth = fieldValue.substring(2, 4);
		sDate = fieldValue.substring(0, 2);
		return new Array(sYear, sMonth, sDate);
	}
	matched = fieldValue.match(/(^[0-9][0-9][0-9][0-9])[/-]([0-9]{1,2})[/-]([0-9]{0,1}[0-9]$)/); // YYYY-MM-DD
	if (matched) {
		sYear = matched[1];
		sMonth = matched[2];
		sDate = matched[3];
		if (Number(sYear) < 1000) {
			// '0005-12-31'のような入力は不正とする
			return [];
		}
		return new Array(sYear, sMonth, sDate);
	}
	return [];
}

function getMDYDateElements(fieldValue) {
	var matched;
	var sYear;
	var sMonth;
	var sDate;
	matched = fieldValue.match(/(^[0-9]{1,2})[/-]([0-9]{0,1}[0-9])[/-]([0-9][0-9][0-9][0-9]$)/); // MM-DD-YYYY
	if (matched) {
		sYear = matched[3];
		sMonth = matched[1];
		sDate = matched[2];
		if (Number(sYear) < 1000) {
			// '12-31-0005'のような入力は不正とする
			return [];
		}
		return new Array(sYear, sMonth, sDate);
	}
	matched = fieldValue.match(/(^[0-9]{1,2})[/-]([0-9]{0,1}[0-9])[/-]([0-9][0-9]$)/); // MM-DD-YY
	if (matched) {
		sYear = matched[3];
		sMonth = matched[1];
		sDate = matched[2];
		return new Array(sYear, sMonth, sDate);
	}
	matched = fieldValue.match(/^[0-9][0-9]{6}[0-9]$/); // MMDDYYYY
	if (matched) {
		sYear = fieldValue.substring(4, 8);
		sMonth = fieldValue.substring(0, 2);
		sDate = fieldValue.substring(2, 4);
		if (Number(sYear) < 1000) {
			// '12310005'のような入力は不正とする
			return [];
		}
		return new Array(sYear, sMonth, sDate);
	}
	matched = fieldValue.match(/^[0-9][0-9]{4}[0-9]$/); // MMDDYY
	if (matched) {
		sYear = fieldValue.substring(4, 6);
		sMonth = fieldValue.substring(0, 2);
		sDate = fieldValue.substring(2, 4);
		return new Array(sYear, sMonth, sDate);
	}
	matched = fieldValue.match(/(^[0-9][0-9][0-9][0-9])[/-]([0-9]{1,2})[/-]([0-9]{0,1}[0-9]$)/); // YYYY-MM-DD
	if (matched) {
		sYear = matched[1];
		sMonth = matched[2];
		sDate = matched[3];
		if (Number(sYear) < 1000) {
			// '0005-12-31'のような入力は不正とする
			return [];
		}
		return new Array(sYear, sMonth, sDate);
	}
	return [];
}

function getYMDDateElements(fieldValue) {
	var matched;
	var sYear;
	var sMonth;
	var sDate;
	matched = fieldValue.match(/(^[0-9][0-9][0-9][0-9])[/-]([0-9]{1,2})[/-]([0-9]{0,1}[0-9]$)/); // YYYY-MM-DD
	if (matched) {
		sYear = matched[1];
		sMonth = matched[2];
		sDate = matched[3];
		if (Number(sYear) < 1000) {
			// '0005-12-31'のような入力は不正とする
			return [];
		}
		return new Array(sYear, sMonth, sDate);
	}
	matched = fieldValue.match(/(^[0-9][0-9])[/-]([0-9]{1,2})[/-]([0-9]{0,1}[0-9]$)/); // YY-MM-DD
	if (matched) {
		sYear = matched[1];
		sMonth = matched[2];
		sDate = matched[3];
		return new Array(sYear, sMonth, sDate);
	}
	matched = fieldValue.match(/^[0-9][0-9]{6}[0-9]$/); // YYYYMMDD
	if (matched) {
		sYear = fieldValue.substring(0, 4);
		sMonth = fieldValue.substring(4, 6);
		sDate = fieldValue.substring(6, 8);
		if (Number(sYear) < 1000) {
			// '00051231'のような入力は不正とする
			return [];
		}
		return new Array(sYear, sMonth, sDate);
	}
	matched = fieldValue.match(/^[0-9][0-9]{4}[0-9]$/); // YYMMDD
	if (matched) {
		sYear = fieldValue.substring(0, 2);
		sMonth = fieldValue.substring(2, 4);
		sDate = fieldValue.substring(4, 6);
		return new Array(sYear, sMonth, sDate);
	}
	return [];
}

function validateTime(fieldValue) {
	var sep = fieldValue.indexOf(' ');
	var sDate;
	var sTime;
	if (sep > 0) {
		sDate = fieldValue.substring(0, sep);
		sTime = fieldValue.substring(sep + 1);
	} else {
		sDate = fieldValue;
		sTime = "";
	}
	if (!validateDate(sDate)) {
		return false;
	}
	if (sTime != "") {
		var elements = getTimeElements(sTime);
		if (elements.length != 3) {
			return false;
		}
		if (_dateValidateStrict) {
			var iHour = Number(elements[0]);
			var iMinute = Number(elements[1]);
			var iSecond = Number(elements[2]);
			if (iHour < 0 || iHour > 23) {
				return false;
			}
			if (iMinute < 0 || iMinute > 59) {
				return false;
			}
			if (iSecond < 0 || iSecond > 59) {
				return false;
			}
		}
	}
	return true;
}

function getTimeElements(sTime) {
	var matched;
	var sHour;
	var sMinute;
	var sSecond;
	matched = sTime.match(/(^[0-9][0-9]{0,1})[:]([0-9]{0,1}[0-9]$)/); // HH:MM
	if (matched) {
		sHour = matched[1];
		sMinute = matched[2];
		return new Array(sHour, sMinute, "00");
	}
	matched = sTime.match(/(^[0-9][0-9]{0,1})[:]([0-9]{1,2})[:]([0-9]{0,1}[0-9]$)/); // HH:MM:SS
	if (!matched) {
		matched = sTime.match(/(^[0-9][0-9]{0,1})[:]([0-9]{1,2})[:]([0-9]{1,2})[.]([0-9]*[0-9]$)/); // HH:MM:SS.mmm
	}
	if (matched) {
		sHour = matched[1];
		sMinute = matched[2];
		sSecond = matched[3];
		return new Array(sHour, sMinute, sSecond);
	}
	return [];
}

function isMatchAny(fieldValue, checkType) {
	for(var i = 0; true; i++) {
		var name = checkType + '_' + i;
		if (_regList[name]) {
			if(fieldValue.match(_regList[name])) {
				return true;
			}
		} else {
			break;
		}
	}
	return false;
}

function isSingleByte(str, hankana) {
	if(hankana==undefined) hankana = false;
	var code;
	var result = true;
	for(var i = 0; i < str.length; i++) {
		code = str.charCodeAt(i);
		if(!(0 <= code && code <= 255) || (hankana && !(65382 <= code && code <= 65439))) {
			result = false;
			break;
		}
    }
    return result;
}
function isDoubleByte(str, hankana) {
	if(hankana==undefined) hankana = false;
	var code;
	var result = true;
	str = str.replace(RegExp("\\r\\n*", "gm"), "");
	for(var i = 0; i < str.length; i++) {
		code = str.charCodeAt(i);
		if((0 <= code && code <= 255) || (hankana && (65382 <= code && code <= 65439))) {
			result = false;
			break;
		}
    }
    return result;
}
function isKeyCodeAlphabet(code) {
	if((65 <= code && code <= 90) || (97 <= code && code <= 122)) {
		return true;
	}
	return false;
}
function isNumKeyCode() {
	var code = getKeyCode();
	if(isSeparator(code)){
		return true;
	}
	if(isKeyCodeAlphabet(code)) {
		_noInput = true;
		return false;
	}
	if((33 <= code && code <= 42) || code == 47 || code == 44 || code == 46 || (58 <= code && code <= 64) || (91 <= code && code <= 96) || (123 <= code && code <= 126)) {
		_noInput = true;
		return false;
	}
	return true;
}
function isSeparator(code){
	 return (String.fromCharCode(code) == _groupingSeparator.charAt(0) || String.fromCharCode(code) == _decimalSeparator.charAt(0));
}
function isCurrencyKeyCode() {
	var code = getKeyCode();
//	if(isCurrencyKeyCodeLocale(String.fromCharCode(code))) return true;
	if(isCurrencyKeyCodeLocale(code)) return true;
	if(!isNumKeyCode()) {
		_noInput = true;
		return false;
	}
	return true;
}
function isCurrencyKeyCodeLocal(code) {
//	return (code == 92 || code == 36);
	return (code == 92);
}
function isCodeKeyCode() {
	var code = getKeyCode();
	if((33 <= code && code <= 44) || code == 47 || (58 <= code && code <= 63) || (91 <= code && code <= 94) || code == 96 || (123 <= code && code <= 126)) {
		_noInput = true;
		return false;
	}
	return true;
}
function isDateKeyCode() {
	var code = getKeyCode();
	if(isKeyCodeAlphabet(code)) {
		_noInput = true;
		return false;
	}
	if((33 <= code && code <= 44) || code == 46 || (58 <= code && code <= 64) || (91 <= code && code <= 96) || (123 <= code && code <= 126)) {
		_noInput = true;
		return false;
	}
	return true;
}
function isTimeKeyCode() {
	var code = getKeyCode();
	if(code == 58) return true;
	if(!isDateKeyCode()) {
		_noInput = true;
		return false;
	}
	return true;
}
function moveCheckBox(name, index) {
	var keyCode = getKeyCode();
	if(keyCode >= 37 && keyCode <= 40) {
		if(keyCode == 37 || keyCode == 38) {
			index = index - 1;
		} else if(keyCode == 39 || keyCode == 40) {
			index = index + 1;
		}
		var items = document.getElementsByName(name);
		if(index >= 0 && index < items.length) {
			asyncFocus(items[index]);
		}
	}
}
function onkeyDown4murtiCheckBox(code) {
	var keyCode = getKeyCode();
	if(keyCode >= 37 && keyCode <= 40) {
		keyDownCansel = true;
	} else {
		cursor_onKeyDown(code);
	}
}
function isBlank(str) {
	if(str == undefined || str == null || str == "") {
		return true;
	}
	return false;
}
function isNull(str) {
	if(str == undefined || str == null) {
		return true;
	}
	return false;
}


/**
 * ファイルクリア時にサーバーへの通知を行う。
 *
 * @param action Action名
 * @param param パラメータ
 */
function event_fileclear( action, param ) {
//	document.forms[0]._status.value = "UPDATE"; // クリアしたので更新フラグを立てる
	getForm()._status.value = "UPDATE"; // クリアしたので更新フラグを立てる
	if (oldFocus != "") {
		if (isChangeField(oldFocus)) {
			param = param + "," + oldFocus;
		}
	}
	buttonAction(action, param, _globalMsgObject.sending, "0");
}
/**
 * 画面表示情報をJSON化します。
 * （スクロール位置、一覧スクロール位置、一覧ソート条件、一覧ページ位置）
 */
function toJsonDisplayInfo() {
	var columnList;
	var colsize;
	var i;
	var j;
	var len;
	var gname;
	var gcode;
	var dm = "";

	var dispInfo = "{"; // grobal start

	var pos = getDispPos();
	dispInfo += ("_posx:" + pos["x"]);
	dispInfo += (",_posy:" + pos["y"]);


	len = disp._groupList.length;
	for(i=0; i < len; i++){
		gcode = disp._groupList[i];
		var groupMetaInfo = disp.getMetaInfo(gcode);
		if( groupMetaInfo.hasScroll ){
			gname = groupMetaInfo.ioItemPropName;
			dispInfo += (",_scrollTop_" + gname + ":" + this["tableCtl_" + gname].getScrollTop() );
		}
	}

	for(i=0; i < len; i++){
		gcode = disp._groupList[i];
		var groupMetaInfo = disp.getMetaInfo(gcode);
		if( groupMetaInfo.hasEnhancedScroll ){
			gname = groupMetaInfo.ioItemPropName;
			dispInfo += (",_scrollTop_" + gname + ":" + this["tableCtl_" + gname].getScrollTop() );
			dispInfo += (",_scrollLeft_" + gname + ":" + this["tableCtl_" + gname].getScrollLeft() );
		}
	}

	dispInfo += (",_bean:{"); // bean start

	for(i=0; i < len; i++){
		gcode = disp._groupList[i];
		var groupMetaInfo = disp.getMetaInfo(gcode);
		gname = groupMetaInfo.ioItemPropName;

		dispInfo += (dm + gname + ":{"); // group start
		dispInfo += ("_length:" + disp.getLength(gcode));
		dispInfo += (",_offset:" + disp.getOffset(gcode));

		columnList = groupMetaInfo.columnList;
		colSize = columnList.length;
		for( j=0; j < colSize ; j++ ){
			var fieldMetaInfo = disp["metaInfo_"+columnList[j]];

			var sort = getItemById(gname + "." + fieldMetaInfo.getSortConditionName());
			if(sort){
				if(sort.value && sort.value != ""){
					dispInfo += ("," + fieldMetaInfo.getSortConditionName() +":" + sort.value);
					break;
				}
			}
		}
		dispInfo += "}";// group end
		dm = ",";
	}
	dispInfo += "}"; // bean end
	dispInfo += "}"; // grobal end
	return dispInfo;
}

/**
 * ログアウトします。
 */
function wpLogout(){
	try {
		var url = disp.form.action;
		var params = ('method=event_Logout');
		sendRequest("POST",url,false,function(jsonData, err){/*ignore*/},params,disp._encoding);
	} catch (e) {
		// ignore
	}
}

/**
 * グループ項目のソート状態を設定します
 */
function set_UISortCondition(ioItemCode, order) {
	var e = getItemById("sid" + ioItemCode +"_Label");
	if (e) {
		// ラベル項目を基準にINPUTタグを検索
		var s = e.getElementsByTagName("INPUT")[0];
		if (s) {
			s.value = order;
		}
	}
}

/**
 * 一覧の表示条件をリセットします。
 */
function resetGroupDisplayInfo() {
	var len = disp._groupList.length;
	for(var i=0; i < len; i++){
		var gcode = disp._groupList[i];
		var groupMetaInfo = disp.getMetaInfo(gcode);
		var gname = groupMetaInfo.ioItemPropName;

		if (_global_isMSIE) {
			getItemById( gname + "._offset" ).value = "0";
		} else {
			var eGOffsetList = document.getElementsByName( gname + "._offset" );
			var eGOffset = undefined;
			if(eGOffsetList != null) {
				if(eGOffsetList.length != undefined) {
					for(var _count_eGOffsetList = 0; _count_eGOffsetList < eGOffsetList.length; _count_eGOffsetList++) {
						eGOffset = eGOffsetList.item(_count_eGOffsetList);
						eGOffset.value = "0";
					}
				}
			}
		}

		var columnList = groupMetaInfo.columnList;
		var colSize = columnList.length;
		for( var j=0; j < colSize ; j++ ){
			var fieldMetaInfo = disp["metaInfo_"+columnList[j]];
			if (_global_isMSIE) {
				var sort = getItemById(gname + "." + fieldMetaInfo.getSortConditionName());
				if(sort){
					if(sort.value && sort.value != ""){
						sort.value = "";
						break;
					}
				}
			} else {
				var eSortList = document.getElementsByName(gname + "." + fieldMetaInfo.getSortConditionName());
				var sort = undefined;
				if(eSortList != null) {
					if(eSortList.length != undefined) {
						for(var count_eSortList = 0; count_eSortList < eSortList.length; count_eSortList++) {
							sort = eSortList.item(count_eSortList);
							if(sort){
								if(sort.value && sort.value != ""){
									sort.value = "";
									break;
								}
							}
						}
					}
				}
			}
		}
	}
}

/**
 * 空白をHTML文字にエスケープ
 *
 * @str 対象文字列
 */
function escapeWhiteSpace(str){
	return str.replace(/\n/gm, "<br>").replace(/\r/gm, "").replace(/ /gm, "&nbsp;");
}

/**
 * フィールド出力項目（O）の表示値を設定します。
 *
 * @param dispElem 表示用要素
 * @param dispValue 表示文字
 */
function setOutFieldDispValue(dispElem,dispValue) {
	var textPropName = '';
	if (typeof dispElem.textContent != 'undefined') {
		textPropName = "textContent";
	} else {
		textPropName = "innerText";
	}

	if(dispElem[textPropName]=="" && dispValue==""){
		// 互いに空の時はなにもしない
		return;
	}
	changeTextContent(dispElem,dispValue);
}

/**
 * ブラウザーを識別します。
 */
function browzerType() {
	var ua = (navigator.userAgent ? navigator.userAgent.toLowerCase() : null);
	if(ua != null && (ua.indexOf("msie") != -1 || ua.indexOf("trident") != -1)){
		_global_isMSIE = true;
		return ;
	}else if(ua != null && (ua.indexOf("edge") != -1)){
		_global_isMSEDGE = true;
		return ;
	}else if(ua != null && ua.indexOf("chrome") != -1){
		_global_isCHROME = true;
		return ;
	}else if(ua != null && ua.indexOf("safari") != -1){
		_global_isSAFARI = true;
		return ;
	}else if(ua != null && ua.indexOf("firefox") != -1){
		_global_isFIREFOX = true;
		return ;
	}
}

_global_isMSIE = false;
_global_isMSEDGE = false;
_global_isSAFARI = false;
_global_isCHROME = false;
_global_isFIREFOX = false;

browzerType();

function isEnableRichText(){
	return (!isHTML5() && _global_isMSIE) || (isHTML5() && !(_global_isIPHONE || _global_isANDROID || _global_isIPOD || _global_isIPAD));
}


/**
 * IEのバージョンを取得します.
 * IE以外のブラウザから使用した場合は-1が返ります.
 *
 */
function getIEVer() {
	if (!_global_isMSIE) {
		return -1;
	}
	var ua = navigator.userAgent ? navigator.userAgent.toLowerCase() : '';
	var array = /(msie|rv:?)\s?([\d\.]+)/.exec(ua);
	var version = (array) ? Number(array[2]) : -1;
//	console.log(version);
	return version;
}

/**
 * イベントオブジェクトをwindow.eventで参照できるように設定します。
 * @param ev イベントオブジェクト
 */
function setupEvent(ev) {
	if (!(_global_isMSIE || _global_isMSEDGE)) {
		window.event = ev;
	}
}

/**
 * モーダルダイアログを閉じた後、
 * モーダルダイアログを開くボタンへフォーカスを復旧します。
 * @param fieldName ボタンの名前
 */
function recoverFocus( fieldName ){
	if( _global_isSAFARI || _global_isCHROME ){
		if (!document.activeElement || document.activeElement.tagName == "BODY") {
			if( _global_isSAFARI ){
				asyncFocus(window);
			}
			asyncFocus(getItemByName(fieldName));
		}
	}
}

/**
 * シフトキーが押されているか判定します。
 * @returns シフトキーが押されているときtrue, 押されていないときfalse
 */
function isShitKeyPressed() {
	return window.event.shiftKey;
}

/**
 * テキストを変更します。
 * @param elem 要素
 * @param val 値
 */
function changeTextContent(dispElem, dispValue){
	if(_global_isMSIE || _global_isMSEDGE){
		if (typeof dispValue == 'string') {
			if(dispValue.charAt(0) == " " && dispValue.charAt(1) != " "){
				// innerTextで、先頭に単独のスペースがあった場合、そのスペースが表示されない不具合の対応
				dispElem.innerHTML = escapeWhiteSpace(escapeHTML(dispValue));
				return;
			}
		}
		dispElem.innerText = dispValue;
	}else if(_global_isFIREFOX){
		if(typeof dispValue == 'string'){
			dispElem.innerHTML = escapeWhiteSpace(escapeHTML(dispValue));
		}else{
			dispElem.innerHTML = dispValue;
		}
	}else if(_global_isCHROME || _global_isSAFARI){
		var escapedDispValue = dispValue;
		if(typeof dispValue == 'string'){
			escapedDispValue = escapeWhiteSpace(escapeHTML(dispValue));
		}
		if (dispElem.hasChildNodes()) {
			dispElem.innerHTML = escapedDispValue;
		}else{
			var p = dispElem.parentNode;
			var nextEl = getElementNext(p, dispElem);
			var spanNode = p.removeChild(dispElem);
			if (isMobile()) {
				// androidでのエラーを回避
				// NO_MODIFICATION_ALLOWED_ERR: DOM Exception 7
				$(spanNode).html(escapedDispValue);
			} else {
				spanNode.innerHTML = escapedDispValue;
			}
			p.insertBefore(spanNode, nextEl);
		}
	}else{
		// no support browzer
	}
}

function getElementNext(parent, el) {
	var child = parent.firstChild;
	while (child != null) {
		if (child == el) {
			return child.nextSibling;
		}
		child = child.nextSibling;
	}
	return null;
}

/**
 * ダイアログを開き、呼び出し元画面を入力禁止にします。
 * @param uri ダイアログで開くページのURI
 * @param args ダイアログのパラメータ
 * @param options showModalDialog関数のオプション文字列
 * @return ダイアログの戻り値
 */
function showDialogPreventInput(uri, args, options) {
	if (!(isMSIE() || isMSEdge())) {
		preventInput(true);
	}
	var result = showModalDialog(uri, args, options);
	if (!(isMSIE() || isMSEdge())) {
		preventInput(false);
	}
	return result;
}

function preventInput(preventIt) {
	if (preventIt) {
		setScreenLock(true);
		disp_ScreenLock();
		document.body.style.cursor = "wait";
	} else {
		document.body.style.cursor = "";
		clear_ScreenLock();
		setScreenLock(false);
	}
}

var _dialogArguments;
var _dialogOpen = false;
var _dialogWindow;
var _dialogCallBack;
/**
 * ダイアログを開き、呼び出し元画面を入力禁止にします。
 * （疑似 showModalDialogを表示）
 * @param uri ダイアログで開くページのURI
 * @param args ダイアログのパラメータ
 * @param options window.open関数のオプション文字列
 */
function showDialog(uri, args, options) {
	features = "toolbar=no"
		+ ",menubar=no"
		+ ",location=no"
		+ ",directories=no"
//		+ ",dialog=yes" // Firefoxのみ有効。最小化／最大化ボタンを表示しない
		;

	if (options.indexOf("=") >= 0) {
		// wiondow.open用のパラメータ
		features += "," + options
	} else {
		// showModalDialog用のパラメータ(旧バージョンとの互換のため)
		var array = options.split(";");
		for (var i = 0; array.length > i; i++) {
			var param = array[i].split(":");
			var key = param[0].replace(/(^\s+)|(\s+$)/g, "");
			var value = "";
			if (param.length >= 2) {
				value = param[1].replace(/(^\s+)|(\s+$)/g, "");
			}
			features += ",";
			if (key == "dialogWidth") {
				key = "width";
			} else if (key == "dialogHeight") {
				key = "height";
			} else if (key == "dialogTop") {
				key = "top";
			} else if (key == "dialogLeft") {
				key = "left";
			} else if (key == "status") { // 共通
			} else if (key == "scroll") {
				key = "scrollbars";
				if (value.length == 0) {
					value = "yes";
				}
			} else if (key == "resizable") { // 共通
				if (value.length == 0) {
					value = "yes";
				}
			}
			features += key;
			if (value.length > 0) {
				features += "=" + value;
			}
		}
	}
	features += getDialogCenterPos(features);

	_dialogArguments = args;
	_dialogOpen = true;

	preventInput(true);

	_dialogWindow = window.open(uri, "_blank", features);

	if(hasParent()){
		layer = window.parent.getItemById("_slock");
		window.parent._dialogWindow = _dialogWindow;
		window.parent._dialogOpen = _dialogOpen;
		window.parent.preventInput(true);
	}

	document.body.style.cursor = "";
}

/**
 * ダイアログをメインモニタ中央に表示するための top・left を返します。
 * window.open には center 特性が無いがshowModalDialogとの互換を保つ為の処理
 * パラメータが以下の条件を全て満たしていることを条件とする
 * ・centerが yes または 1
 * ・widthが 0 以上
 * ・heightが 0 以上
 * topまたはleftの指定がある場合は指定された値を優先します。
 * 制限
 * ・サブモニタがある場合、中央に表示されない場合があります。
 * @param features window.openの特性
 */
function getDialogCenterPos(features) {
	var ret = "";
	var height = 0;
	var width = 0;
	var isCenter = false;
	var dialogLeft;
	var dialogTop;

	var array = features.split(",");
	for (var i = 0; array.length > i; i++) {
		var param = array[i].split("=");
		var key = param[0].replace(/(^\s+)|(\s+$)/g, ""); // trim
		var value = "";
		if (param.length >= 2) {
			value = param[1].replace(/(^\s+)|(\s+$)/g, "") // trim;
		}
		if (key == "center") {
			if (value == "" || value == "yes" || value == "1") {
				isCenter = true;
			} else {
				break;
			}
		} else if (key == "width" || key == "height") {
			value = value.replace(/(\D+$)/g, ""); // 単位部分を除去
			try {
				value = parseInt(value); // 数値変換
			} catch (e) {
				break;
			}
			if (value == 0) {
				break;
			} else if ( value < 100) {
				value = 100; // 最少値は100
			}
			if (key == "width") {
				width = value;
			} else {
				height = value;
			}
		} else if (key == "left") {
			dialogLeft = value;
		} else if (key == "top") {
			dialogTop = value;
		}
	}

	if (!isCenter) {
		return ret;
	}

	// モニタのサイズを取得
	// IE では、プライマリモニタの幅と高さを返す。
	// IE以外ではサブモニタの幅と高さを返す場合がある。
	var screenWidth = window.screen.width;
	var screenHeight = window.screen.height;

	if (!dialogLeft && width > 0) {
		dialogLeft = (screenWidth - width) / 2;
		ret += ",left=" + dialogLeft + "px";
	}
	if (!dialogTop && height > 0) {
		dialogTop = (screenHeight - height) / 2;
		ret += ",top=" + dialogTop + "px";
	}

	return ret;
}

/**
 * ダイアログ画面が閉じるときの処理。
 */
function dialogCloseProc() {
	var mainWindow = top.opener;
	if (!mainWindow) {
		return;
	}

	mainWindow.dialogClosed();

	if (parent.returnValue) {
		// OKボタンの処理を実行する
		mainWindow._dialogCallBack(parent.returnValue);
	}

	parent.close();
}

/**
 * ダイアログを閉じられた後のダイアログ画面開き元の後処理。
 */
function dialogClosed() {
	_dialogOpen = false;
	preventInput(false);
	_dialogWindow = null;
	_dialogArguments = null;
}

function getDialogArguments() {
	return _dialogArguments;
}

/**
 * ダイアログ画面開き元でダイアログを閉じる処理。
 * （ダイアログ画面開き元はさわれないはずだが念のため）
 */
function close_Dialog() {
	if (_dialogWindow) {
		// ダイアログ画面を開いていたら閉じる
		_dialogWindow.close();
		dialogClosed();
	}
}

/**
 * ダイアログ画面開き元のフォーカスイベントの処理。
 */
function focus_Dialog() {
	if (_dialogOpen) {
		if (!_dialogWindow || _dialogWindow.closed) {
			// ダイアログ画面が×ボタンなどで閉じられたとき、開き元をさわれるようにします。
			dialogClosed();
		} else {
			// フォーカスをダイアログ画面に移します。
			_dialogWindow.focus();
		}
	}
}

/**
 * 非同期で項目にフォーカスを設定します。
 * IE以外のブラウザーではfocus関数内でfocusイベントハンドラーが実行されます。
 * @param focusControl 項目
 * @param selectIt 選択状態を変更するときtrue, 変更しないときfalse
 */
function asyncFocus(focusControl, selectIt) {
	window.setTimeout(function() {
		try{
			focusControl.focus();
			if (selectIt) {
				if (focusControl.type == "text" || focusControl.type == "file" || focusControl.type == "password") {
					selectTextRange(focusControl, true);
				} else if(focusControl.tagName == "TEXTAREA"){
					selectTextRange(focusControl, false);
				}
			}
			if (isMobile()) {
				showFixedToolbar();
			}
		}catch(e){/*ignore*/}
	}, 0);
}

window.onpageshow = function(ev) {
	if (ev && ev.persisted) {
		if (_dialogOpen && _dialogWindow) {
			// iPad7ではタブで遷移した場合もイベントが発生する
			// ダイアログ表示時、開き元がさわられた場合はスクリーンロックを解除しない
			return true;
		}
		document.body.style.cursor = "";
		if (window.clearSendMsg) {
			clearSendMsg();
		}
		clear_ScreenLock();
		setScreenLock(false);
	}
	return true;
}
function richTextButtonDisabled() {
	if (!isEnableRichText()) {
		var _elements = getItemsById('richToolbar');
		if(!_elements) {
			_elements = document.getElementsByClassName("RICHTEXT_TOOLBAR");
		}

		if(_elements != null) {
			if(isListItems(_elements)) {
				var len = _elements.length;
				for(var i = 0; i < len; i++) {
					hideRichTextToolbarButtons(_elements.item(i));
				}
			} else {
				hideRichTextToolbarButtons(_elements);
			}
		}
	}
}

function hideRichTextToolbarButtons(richTextToolbar){
	// 条件によりボタンの数は異なるが、最大２つのボタンを非表示にする。
	var firstElement = richTextToolbar.children.item(0);
	var secondElement = richTextToolbar.children.item(1);
	if(firstElement.tagName.toUpperCase() == 'INPUT'){
		firstElement.style.visibility="hidden";
	}
	if(secondElement.tagName.toUpperCase() == 'INPUT'){
		secondElement.style.visibility="hidden";
	}
}

function normalizeCRLF(val) {
	return (val ? val.replace(/(\r\n|\r|\n)/g, "\r\n") : val);
}

function statusbarPosition(div) {
	var clientHeight = getTopWindowClientHeight();
	var scrollTop = window.top.document.body.scrollTop;
	var clientTop = window.top.document.body.clientTop;
	var clientWidth = getTopWindowClientWidth();
	var scrollLeft = window.top.document.body.scrollLeft;
	var clientLeft = window.top.document.body.clientLeft;

	if(scrollTop > 0) {
		div.style.top = "";
		div.style.top = scrollTop + clientTop + clientHeight - div.offsetHeight;
	} else {
		div.style.top = "";
		div.style.bottom = 0;
	}

	if(scrollLeft > 0) {
		div.style.left = "";
		div.style.left = scrollLeft + clientLeft + clientWidth - div.offsetWidth;
	} else {
		div.style.left = "";
		div.style.right = 0;
	}
}

var mobileMode = false;
function isMobile() {
	return mobileMode;
}

function showStatusBar(msg,type) {
	var msg_str = undefined;
	if(msg.message != undefined) {
		msg_str = msg.message;
	} else {
		msg_str = msg;
	}
	if (isMobile()) {
		if (type == "ERROR" && msg_str) {
			alert(msg_str);
		}
		return;
	}

	window.status = msg_str;
	if(_statusbar_mode == 1 || (_statusbar_mode == 2 && type == "ERROR") || type == "STATIC") {
		var doc = window.top.document;
		var status_bar = doc.getElementById('_statusbar');
		if (status_bar) {
			if(type == "ERROR") {
				status_bar.className = "ERR_STATUSBAR";
			} else {
				status_bar.className = "STATUSBAR";
			}

			var status_bar_image = doc.getElementById('_statusbar-image');
			var status_bar_text = doc.getElementById('_statusbar-text');

			status_bar_text = status_bar_text || status_bar;
			changeTextContent(status_bar_text, msg_str);

			if(status_bar_image){
				if(type == "ERROR") {
					status_bar_image.className = "statusbar-image_error";
				} else {
					status_bar_image.className = "statusbar-image_info";
				}
			}

			if (msg) {
				//suggest対策によりstatus_bar要素必ずnone
				status_bar.style.display = 'none';
				status_bar.style.display = 'block';
				status_bar.onclick = function() {
					status_bar.style.display = 'none';
				}
				if(_global_isMSIE || _global_isMSEDGE) {
					statusbarPosition(status_bar);
				}
			} else {
				status_bar.style.display = 'none';
			}
		}
	}
}

function isMSEdge() {
	browzerType();
	return _global_isMSEDGE;
}

function isMSIE(){
	browzerType();
	return _global_isMSIE;
}

function isSafari(){
	browzerType();
	return _global_isSAFARI;
}

function isChrome(){
	browzerType();
	return _global_isCHROME;
}

function isFirefox(){
	browzerType();
	return _global_isFIREFOX;
}

function deviceType() {
	var ua = (navigator.userAgent ? navigator.userAgent.toLowerCase() : null);
	if (ua != null && ua.indexOf("iphone;") != -1){
		_global_isIPHONE = true;
	} else if (ua != null && ua.indexOf("ipad;") != -1){
		_global_isIPAD = true;
	} else if (ua != null && ua.indexOf("ipod;") != -1){
		_global_isIPOD = true;
	} else if(ua != null && ua.indexOf("macintosh") != -1){
		_global_isMACINTOSH = true;
	} else if (ua != null && ua.indexOf("android") != -1){
		_global_isANDROID = true;
	}
}
_global_isIPHONE = false;
_global_isIPAD = false;
_global_isIPOD = false;
_global_isMACINTOSH = false;
_global_isANDROID = false;
deviceType();
function isIPhone() {
	return _global_isIPHONE;
}
function isIPad() {
	return _global_isIPAD;
}
function isIPod() {
	return _global_isIPOD;
}
function isMacintosh() {
	return _global_isMACINTOSH;
}
function isAndroid() {
	return _global_isANDROID;
}

function isHTML5() {
	if (document.compatMode) {
		// HTML4の場合はdocument.compatModeは"BackCompat"を返す
		return document.compatMode == "CSS1Compat";
	}
	return false;
}

// 言語切替JS関数
function changeLanguage(language, fieldName) {
	if (window.top._dialogPage || window._richTextPage) {
		return;
	}

	setLanguage(language);
	event_onClick_withDirtycheck(fieldName, '_CangeLanguageAction','',0);
}

function setLanguage(language) {
	disp.form["_language"].value = language;
}

/**
 * 文字列が指定文字で終わっているかどうか.
 *
 * @function
 * @param str
 *            検査対象の文字列
 * @param suffix
 *            サフィックス
 * @return 終わっている場合true, それ以外はfalse
 */
function endsWith(str, suffix) {
	var sub = str.length - suffix.length;
	return (sub >= 0) && (str.lastIndexOf(suffix) === sub);
}

var mainFormName;
/**
 * メインフォームのnameをセットします.
 *
 * @function
 * @param fromName 対象フォームのname
 */
function setFormName(fromName) {
	mainFormName = fromName;
}

/**
 * フォームオブジェクトを返します.
 *
 * @function
 * @param fromName 対象フォームのname
 * @return フォームオブジェクト
 */
function getForm(fromName) {
	if (typeof eval("document." + fromName) != "undefined") {
		return eval("document." + fromName);
	}
	if (typeof eval("document." + mainFormName) != "undefined") {
		return eval("document." + mainFormName);
	}
	return document.forms[0];
}

/**
 * エラーページの内容をダイアログで表示します.
 *
 * @function
 * @param errdetaildisp 詳細を表示するかどうか？
 * @param ctx コンテキストパス
 * @param errdlgMsgBody リソース「system.errordlg.msg.body」
 * @param errException 例外メッセージ
 * @return void
 */
function showErrorDialog(errdetaildisp, ctx, errdlgMsgBody, errException) {
	if(!(_global_isMSIE || _global_isMSEDGE)) {
		setExportState(false);
	}
	if (!parent._ifrm) {
		return;
	}
	if(parent && parent.closePreopenWindowWhenPrintActionError){
		 parent.closePreopenWindowWhenPrintActionError();
	}

	if (isMSIE()) {
		//エラーメッセージ
		var msg = document.getElementById("_message");
		var msgText = msg.innerHTML;
		//エラー情報
		var errDetail = document.getElementById("error_detail");
		var errDetailText = errDetail.innerHTML;
		var args = new Array();
		args[0] = msgText;
		args[1] = errDetailText;
		args[2] = errdetaildisp;
		var requestURL = ctx + "/page/_DialogMsg.jsp";
		showModalDialog(requestURL, args,
				"resizable:yes; status:no; scroll:yes; dialogHeight:200px; dialogWidth:600px");
	} else {
		var alertMsg = '';
		var messages = document.getElementById("_message");
		var errorMessages = messages.getElementsByClassName("errors-text");
		var warnMessages = messages.getElementsByClassName("warn-text");
		var infoMessages = messages.getElementsByClassName("info-text");
		var eMsgSize = errorMessages.length;
		var wMsgSize = warnMessages.length;
		var iMsgSize = infoMessages.length;
		if (eMsgSize > 0) {
			for (var i = 0; i < eMsgSize; i++) {
				alertMsg += (replaceLine(errorMessages[i]).trim() + '\n');
			}
		}
		if (wMsgSize > 0) {
			for (var i = 0; i < wMsgSize; i++) {
				alertMsg += (replaceLine(warnMessages[i]).trim() + '\n');
			}
		}
		if (iMsgSize > 0) {
			for (var i = 0; i < iMsgSize; i++) {
				alertMsg += (replaceLine(infoMessages[i]).trim() + '\n');
			}
		}
		if (!errdetaildisp) {
			alertMsg += (errdlgMsgBody + '\n' + errException);
		}
		var msg = alertMsg.trim();
		setTimeout(function(){alert(msg);},100); // chrome対応
	}
}

/**
 * HTMLの改行をjavascriptの改行に置き換える
 *
 * @param message メッセージのエレメント
 * @returns メッセージ文字列
 */
function replaceLine(message) {
	return message.innerHTML.split('<br>').join('\n');
}

//リッチテキストダイアログ戻り値格納用変数
var _dlgReturnValue;

function getDlgReturnValue(ret) {
	if (!ret) {
 		// returnValueが空ならグローバルを使う
 		return _dlgReturnValue;
	}
	return ret;
}

function setDlgReturnValue(ret) {
 	_dlgReturnValue = ret;
}

function setExportState(start) {
	var url;
	if (start) {
		url = "./_startExport.do";
	} else {
		url = "./_cleaarExportState.do";
	}
	$.ajax({
		type : 'GET',
		url : url,
		contentType: false,
		async: true,
		dataType: 'text'
	});

}
function getExportState() {
	var ret;
	$.ajax({
		type : 'GET',
		url : "./_exportState.do",
		contentType: false,
		async: false,
		dataType: 'text',
		success: function(data) {
			ret = data;
		}
	});

	return ret;
}

if (typeof(isApplication) == "undefined") {
	isApplication = function () {
		return true;
	};
}

function normalizeCRLF4hidden(sep) {
	if (!_global_isMSEDGE) {
		return;
	}
	if (!(sep == "\r\n" || sep == "\r")) {
		return;
	}
	var elements = document.querySelectorAll("input[type=hidden]");
	for (var i = 0; elements.length > i; i++) {
		var elem = elements[i];
		if (elem.value && elem.value.indexOf(sep) == -1 && elem.value.indexOf("\n") != -1) {
			var param = elem.value;
			elem.value = param.replace(/\n/g, sep);
		}
	}
}

// ファイル読み込み完了
_global_js_load = true;
