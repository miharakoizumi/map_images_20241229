function isCurrencyKeyCodeLocale(code) {
	return (code == 92 || code == '\u00a5');
}
var _regList = new Array(5);
_regList["NUM_0"] = new RegExp("^[+-]?["+_decimalSeparator+"]?[0-9]+$");
_regList["NUM_1"] = new RegExp("^["+_decimalSeparator+"]?[0-9]+[+-]?$");
_regList["NUM_2"] = new RegExp("^[+-]?[0-9]+["+_decimalSeparator+"]?[0-9]*$");
_regList["NUM_3"] = new RegExp("^[0-9]+["+_decimalSeparator+"]?[0-9]*[+-]?$");
_regList["NUM_4"] = new RegExp("^[+-]?[0-9][0-9"+_groupingSeparator+"]+[0-9]$");
_regList["NUM_5"] = new RegExp("^[0-9][0-9"+_groupingSeparator+"]+[0-9][+-]?$");
_regList["NUM_6"] = new RegExp("^[+-]?[0-9][0-9"+_groupingSeparator+"]+[0-9]["+_decimalSeparator+"][0-9]*$");
_regList["NUM_7"] = new RegExp("^[0-9][0-9"+_groupingSeparator+"]+[0-9]["+_decimalSeparator+"][0-9]*[+-]?$");
_regList["CURRENCY_0"] = new RegExp("^[\\\\u00a5]?[+-]?["+_decimalSeparator+"][0-9]*$");
_regList["CURRENCY_1"] = new RegExp("^[\\\\u00a5]?["+_decimalSeparator+"][0-9]*[+-]?$");
_regList["CURRENCY_2"] = new RegExp("^[\\\\u00a5]?[+-]?[0-9]+["+_decimalSeparator+"]?[0-9]*$");
_regList["CURRENCY_3"] = new RegExp("^[\\\\u00a5]?[0-9]+["+_decimalSeparator+"]?[0-9]*[+-]?$");
_regList["CURRENCY_4"] = new RegExp("^[\\\\u00a5]?[+-]?[0-9][0-9"+_groupingSeparator+"]+[0-9]$");
_regList["CURRENCY_5"] = new RegExp("^[\\\\u00a5]?[0-9][0-9"+_groupingSeparator+"]+[0-9][+-]?$");
_regList["CURRENCY_6"] = new RegExp("^[\\\\u00a5]?[+-]?[0-9][0-9"+_groupingSeparator+"]+[0-9]["+_decimalSeparator+"][0-9]*$");
_regList["CURRENCY_7"] = new RegExp("^[\\\\u00a5]?[0-9][0-9"+_groupingSeparator+"]+[0-9]["+_decimalSeparator+"][0-9]*[+-]?$");
_regList["CODE_0"] = new RegExp(/^[a-zA-Z0-9-_@.]*$/);
_statusbar_mode = 1;
