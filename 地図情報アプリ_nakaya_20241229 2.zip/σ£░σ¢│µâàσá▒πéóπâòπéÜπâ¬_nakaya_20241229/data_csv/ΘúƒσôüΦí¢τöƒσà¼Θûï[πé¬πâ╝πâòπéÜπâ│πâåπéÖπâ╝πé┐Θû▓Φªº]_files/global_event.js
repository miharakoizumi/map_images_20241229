/**
 * イベント管理クラス
 * EventHandler
 */
function EventHandler() {
	EventHandler._handler_list = new Array();
	/**
	 * Onload時イベントハンドラ
	 */
	EventHandler.onload = function() {
		var h = EventHandler._handler_list["onload"];
		if (h != undefined){
			for(var i = 0; i < h.length; i++){h[i].onload();}
		}
		event_onLoad();// 画面のonloadを呼び出す
		var h = EventHandler._handler_list["OnAfterLoad"];
		if (h != undefined){
			for(var i = 0; i < h.length; i++){h[i].OnAfterLoad();}
		}
	}
	/**
	 * Onresize時イベントハンドラ
	 */
	EventHandler.onresize = function() {
		var h = EventHandler._handler_list["onresize"];
		if (h == undefined) return;
		for(var i = 0; i < h.length; i++){h[i].onresize();}
	}
	/**
	 * イベントハンドラ登録
	 * private addEventHandler
	 * @param name イベント名('onload' or 'OnAfterLoad' or 'onresize')
	 * @param obj イベントハンドラオブジェクト
	 */
	EventHandler.addEventHandler = function(name, obj) {
		var h = EventHandler._handler_list;
		if (h[name] == undefined){h[name] = new Array();}
		h[name].push(obj);
	}
	/**
	 * onloadイベントハンドラ登録
	 * private addOnLoadHandler
	 * @param obj イベントハンドラオブジェクト
	 */
	EventHandler.addOnLoadHandler = function(obj) {
		this.addEventHandler("onload", obj);
	}
	/**
	 * OnAfterLoadイベントハンドラ登録
	 * private addOnAfterLoadHandler
	 * @param obj イベントハンドラオブジェクト
	 */
	EventHandler.addOnAfterLoadHandler = function(obj) {
		this.addEventHandler("OnAfterLoad", obj);
	}
	/**
	 * onresizeイベントハンドラ登録
	 * private addOnReSizeHandler
	 * @param obj イベントハンドラオブジェクト
	 */
	EventHandler.addOnReSizeHandler = function(obj) {
			this.addEventHandler("onresize", obj);
	}
}
new EventHandler();
onload = EventHandler.onload;
onresize = EventHandler.onresize;


// CustomEvent 4IE Polyfill
(function () {

	  if ( typeof window.CustomEvent === "function" ) return false;

	  function CustomEvent ( event, params ) {
	    params = params || { bubbles: false, cancelable: false, detail: null };
	    var evt = document.createEvent( 'CustomEvent' );
	    evt.initCustomEvent( event, params.bubbles, params.cancelable, params.detail );
	    return evt;
	   }

	  window.CustomEvent = CustomEvent;
	})();
